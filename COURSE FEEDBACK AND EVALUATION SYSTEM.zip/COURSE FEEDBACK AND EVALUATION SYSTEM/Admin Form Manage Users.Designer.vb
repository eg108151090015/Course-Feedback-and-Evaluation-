﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_Form_Manage_Users
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Admin_Form_Manage_Users))
        REPORT = New ToolStripMenuItem()
        COURSES = New ToolStripMenuItem()
        INSTRUCTORS = New ToolStripMenuItem()
        DASHBOARD = New ToolStripMenuItem()
        HelloADMIN = New ToolStripMenuItem()
        adminMenu = New MenuStrip()
        VIEWINSTRUCTORS = New ToolStripMenuItem()
        Label1 = New Label()
        txtStudentID = New TextBox()
        lvStudents = New ListView()
        btnAdd = New Button()
        btnEdit = New Button()
        btnDelete = New Button()
        btnClear = New Button()
        txtPassword = New TextBox()
        Label6 = New Label()
        adminMenu.SuspendLayout()
        SuspendLayout()
        ' 
        ' REPORT
        ' 
        REPORT.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        REPORT.ForeColor = Color.White
        REPORT.Image = CType(resources.GetObject("REPORT.Image"), Image)
        REPORT.ImageAlign = ContentAlignment.MiddleLeft
        REPORT.Name = "REPORT"
        REPORT.Size = New Size(173, 24)
        REPORT.Text = "VIEW FEEDBACK"
        REPORT.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' COURSES
        ' 
        COURSES.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        COURSES.ForeColor = Color.White
        COURSES.Image = CType(resources.GetObject("COURSES.Image"), Image)
        COURSES.ImageAlign = ContentAlignment.MiddleLeft
        COURSES.Name = "COURSES"
        COURSES.Size = New Size(173, 24)
        COURSES.Text = "VIEW COURSES"
        COURSES.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' INSTRUCTORS
        ' 
        INSTRUCTORS.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        INSTRUCTORS.ForeColor = Color.White
        INSTRUCTORS.Image = CType(resources.GetObject("INSTRUCTORS.Image"), Image)
        INSTRUCTORS.ImageAlign = ContentAlignment.MiddleLeft
        INSTRUCTORS.Name = "INSTRUCTORS"
        INSTRUCTORS.Size = New Size(173, 24)
        INSTRUCTORS.Text = "MANAGE USERS"
        INSTRUCTORS.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' DASHBOARD
        ' 
        DASHBOARD.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        DASHBOARD.ForeColor = Color.White
        DASHBOARD.Image = CType(resources.GetObject("DASHBOARD.Image"), Image)
        DASHBOARD.ImageAlign = ContentAlignment.MiddleLeft
        DASHBOARD.Name = "DASHBOARD"
        DASHBOARD.Size = New Size(173, 24)
        DASHBOARD.Text = "DASHBOARD"
        DASHBOARD.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' HelloADMIN
        ' 
        HelloADMIN.BackColor = Color.Transparent
        HelloADMIN.Font = New Font("OCR A Extended", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        HelloADMIN.ForeColor = Color.White
        HelloADMIN.ImageAlign = ContentAlignment.MiddleLeft
        HelloADMIN.Name = "HelloADMIN"
        HelloADMIN.Size = New Size(173, 27)
        HelloADMIN.Text = "Hello, #!"
        ' 
        ' adminMenu
        ' 
        adminMenu.BackColor = Color.FromArgb(CByte(64), CByte(0), CByte(0))
        adminMenu.Dock = DockStyle.Left
        adminMenu.Font = New Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        adminMenu.Items.AddRange(New ToolStripItem() {HelloADMIN, DASHBOARD, COURSES, VIEWINSTRUCTORS, INSTRUCTORS, REPORT})
        adminMenu.Location = New Point(0, 0)
        adminMenu.Name = "adminMenu"
        adminMenu.Size = New Size(186, 500)
        adminMenu.TabIndex = 6
        adminMenu.Text = "Admin Menu"
        ' 
        ' VIEWINSTRUCTORS
        ' 
        VIEWINSTRUCTORS.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        VIEWINSTRUCTORS.ForeColor = Color.White
        VIEWINSTRUCTORS.Image = CType(resources.GetObject("VIEWINSTRUCTORS.Image"), Image)
        VIEWINSTRUCTORS.ImageAlign = ContentAlignment.MiddleLeft
        VIEWINSTRUCTORS.Name = "VIEWINSTRUCTORS"
        VIEWINSTRUCTORS.Size = New Size(173, 24)
        VIEWINSTRUCTORS.Text = "VIEW INSTRUCTORS"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("OCR A Extended", 12F, FontStyle.Bold)
        Label1.ForeColor = Color.White
        Label1.Location = New Point(252, 35)
        Label1.Name = "Label1"
        Label1.Size = New Size(239, 17)
        Label1.TabIndex = 7
        Label1.Text = "Student ID(UserName):"
        ' 
        ' txtStudentID
        ' 
        txtStudentID.Enabled = False
        txtStudentID.Font = New Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtStudentID.Location = New Point(252, 57)
        txtStudentID.Name = "txtStudentID"
        txtStudentID.Size = New Size(239, 26)
        txtStudentID.TabIndex = 8
        ' 
        ' lvStudents
        ' 
        lvStudents.FullRowSelect = True
        lvStudents.GridLines = True
        lvStudents.Location = New Point(252, 89)
        lvStudents.Name = "lvStudents"
        lvStudents.Size = New Size(619, 337)
        lvStudents.TabIndex = 17
        lvStudents.UseCompatibleStateImageBehavior = False
        lvStudents.View = View.Details
        ' 
        ' btnAdd
        ' 
        btnAdd.BackColor = Color.FromArgb(CByte(64), CByte(64), CByte(0))
        btnAdd.Enabled = False
        btnAdd.FlatStyle = FlatStyle.Popup
        btnAdd.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        btnAdd.ForeColor = Color.White
        btnAdd.Location = New Point(252, 442)
        btnAdd.Name = "btnAdd"
        btnAdd.Size = New Size(130, 33)
        btnAdd.TabIndex = 18
        btnAdd.Text = "ADD"
        btnAdd.UseVisualStyleBackColor = False
        ' 
        ' btnEdit
        ' 
        btnEdit.BackColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        btnEdit.Enabled = False
        btnEdit.FlatStyle = FlatStyle.Popup
        btnEdit.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        btnEdit.ForeColor = Color.White
        btnEdit.Location = New Point(416, 442)
        btnEdit.Name = "btnEdit"
        btnEdit.Size = New Size(130, 33)
        btnEdit.TabIndex = 19
        btnEdit.Text = "EDIT"
        btnEdit.UseVisualStyleBackColor = False
        ' 
        ' btnDelete
        ' 
        btnDelete.BackColor = Color.Maroon
        btnDelete.Enabled = False
        btnDelete.FlatStyle = FlatStyle.Popup
        btnDelete.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        btnDelete.ForeColor = Color.White
        btnDelete.Location = New Point(577, 442)
        btnDelete.Name = "btnDelete"
        btnDelete.Size = New Size(130, 33)
        btnDelete.TabIndex = 20
        btnDelete.Text = "DELETE"
        btnDelete.UseVisualStyleBackColor = False
        ' 
        ' btnClear
        ' 
        btnClear.BackColor = Color.Maroon
        btnClear.FlatStyle = FlatStyle.Popup
        btnClear.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        btnClear.ForeColor = Color.White
        btnClear.Location = New Point(741, 442)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(130, 33)
        btnClear.TabIndex = 21
        btnClear.Text = "CLEAR"
        btnClear.UseVisualStyleBackColor = False
        ' 
        ' txtPassword
        ' 
        txtPassword.Enabled = False
        txtPassword.Font = New Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtPassword.Location = New Point(632, 57)
        txtPassword.Name = "txtPassword"
        txtPassword.Size = New Size(239, 26)
        txtPassword.TabIndex = 24
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.BackColor = Color.Transparent
        Label6.Font = New Font("OCR A Extended", 12F, FontStyle.Bold)
        Label6.ForeColor = Color.White
        Label6.Location = New Point(632, 35)
        Label6.Name = "Label6"
        Label6.Size = New Size(228, 17)
        Label6.TabIndex = 23
        Label6.Text = "Password(For Login):"
        ' 
        ' Admin_Form_Manage_Users
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Moccasin
        BackgroundImage = My.Resources.Resources.wallp
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(900, 500)
        Controls.Add(txtPassword)
        Controls.Add(Label6)
        Controls.Add(btnClear)
        Controls.Add(btnDelete)
        Controls.Add(btnEdit)
        Controls.Add(btnAdd)
        Controls.Add(lvStudents)
        Controls.Add(txtStudentID)
        Controls.Add(Label1)
        Controls.Add(adminMenu)
        FormBorderStyle = FormBorderStyle.None
        MaximizeBox = False
        MaximumSize = New Size(900, 500)
        MinimumSize = New Size(900, 500)
        Name = "Admin_Form_Manage_Users"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Admin Form Manage Users"
        adminMenu.ResumeLayout(False)
        adminMenu.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents REPORT As ToolStripMenuItem
    Friend WithEvents COURSES As ToolStripMenuItem
    Friend WithEvents INSTRUCTORS As ToolStripMenuItem
    Friend WithEvents DASHBOARD As ToolStripMenuItem
    Friend WithEvents HelloADMIN As ToolStripMenuItem
    Friend WithEvents adminMenu As MenuStrip
    Friend WithEvents Label1 As Label
    Friend WithEvents txtStudentID As TextBox
    Friend WithEvents lvStudents As ListView
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnEdit As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents VIEWINSTRUCTORS As ToolStripMenuItem
End Class
