﻿Imports MySql.Data.MySqlClient

Public Class Admin_Form_Manage_Users

    Public Property Username As String

    Private Sub Admin_Form_Manage_Users_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        HelloADMIN.Text = "Hello, " & Username & "!"

        lvStudents.View = View.Details
        lvStudents.Columns.Clear()
        lvStudents.Columns.Add("Student ID", 100, HorizontalAlignment.Left)
        lvStudents.Columns.Add("First Name", 150, HorizontalAlignment.Left)
        lvStudents.Columns.Add("Last Name", 150, HorizontalAlignment.Left)
        lvStudents.Columns.Add("Email", 200, HorizontalAlignment.Left)
        lvStudents.Columns.Add("Program", 150, HorizontalAlignment.Left)

        DisplayAllStudents()
        UpdateButtonStates(txtStudentID.Text)
        btnAdd.Enabled = False
    End Sub

    Private Function HasAccount(studentID As String) As Boolean
        Try
            OpenConnection()
            Dim query As String = "SELECT COUNT(*) FROM accounts WHERE username = @username"
            Dim cmd As New MySqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@username", studentID)
            Dim count As Integer = Convert.ToInt32(cmd.ExecuteScalar())
            Return count > 0
        Catch ex As Exception
            MessageBox.Show("Error checking account existence: " & ex.Message)
            Return False
        Finally
            CloseConnection()
        End Try
    End Function

    Private Sub DisplayAllStudents()
        Try
            OpenConnection()

            Dim query As String = "SELECT * FROM students"

            Dim cmd As New MySqlCommand(query, conn)
            Dim reader As MySqlDataReader = cmd.ExecuteReader()

            lvStudents.Items.Clear()

            If reader.HasRows Then
                While reader.Read()
                    Dim item As New ListViewItem(reader("student_id").ToString())
                    item.SubItems.Add(reader("first_name").ToString())
                    item.SubItems.Add(reader("last_name").ToString())
                    item.SubItems.Add(reader("email").ToString())
                    item.SubItems.Add(reader("program").ToString())
                    lvStudents.Items.Add(item)
                End While
            Else
                MessageBox.Show("No students found in the database.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

            reader.Close()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CloseConnection()
        End Try
    End Sub

    Private Function IsUserExists(username As String) As Boolean
        Try
            OpenConnection()
            Dim query As String = "SELECT COUNT(*) FROM accounts WHERE username = @username"
            Dim cmd As New MySqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@username", username)
            Dim count As Integer = Convert.ToInt32(cmd.ExecuteScalar())
            Return count > 0
        Catch ex As Exception
            MessageBox.Show("Error checking user existence: " & ex.Message)
            Return False
        Finally
            CloseConnection()
        End Try
    End Function

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim studentID As String = txtStudentID.Text
        Dim password As String = txtPassword.Text

        If String.IsNullOrWhiteSpace(password) Then
            MessageBox.Show("Please enter a password.")
            Return
        End If

        If IsUserExists(studentID) Then
            MessageBox.Show("The student already has an account.")
            Return
        End If

        Try
            OpenConnection()

            Dim userQuery As String = "INSERT INTO accounts (userID, username, password, role) " &
                                  "VALUES (@userID, @username, @Password, @Role)"
            Dim userCmd As New MySqlCommand(userQuery, conn)
            userCmd.Parameters.AddWithValue("@userID", "userID")
            userCmd.Parameters.AddWithValue("@username", studentID)
            userCmd.Parameters.AddWithValue("@Password", password)
            userCmd.Parameters.AddWithValue("@Role", "student")
            userCmd.ExecuteNonQuery()

            MessageBox.Show("Account added successfully!")
            ClearFields()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CloseConnection()
        End Try
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        If lvStudents.SelectedItems.Count > 0 Then
            Dim selectedItem As ListViewItem = lvStudents.SelectedItems(0)
            Dim studentID As String = selectedItem.SubItems(0).Text
            Dim newPassword As String = txtPassword.Text

            If String.IsNullOrWhiteSpace(newPassword) Then
                MessageBox.Show("Please enter a new password.")
                Return
            End If

            Try
                OpenConnection()

                Dim checkUserQuery As String = "SELECT COUNT(*) FROM accounts WHERE username = @username"
                Dim checkUserCmd As New MySqlCommand(checkUserQuery, conn)
                checkUserCmd.Parameters.AddWithValue("@username", studentID)
                Dim userExists As Integer = Convert.ToInt32(checkUserCmd.ExecuteScalar())

                If userExists > 0 Then
                    Dim updateUserQuery As String = "UPDATE accounts SET password = @Password WHERE username = @username"
                    Dim updateUserCmd As New MySqlCommand(updateUserQuery, conn)

                    updateUserCmd.Parameters.AddWithValue("@username", studentID)
                    updateUserCmd.Parameters.AddWithValue("@Password", newPassword)

                    Dim rowsAffected As Integer = updateUserCmd.ExecuteNonQuery()

                    If rowsAffected > 0 Then
                        MessageBox.Show("Password updated successfully!")
                    Else
                        MessageBox.Show("Password update failed.")
                    End If
                Else
                    MessageBox.Show("No matching user found. Password update failed.")
                End If

                ClearFields()
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                CloseConnection()
            End Try
        Else
            MessageBox.Show("Please select a user to edit.")
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If lvStudents.SelectedItems.Count > 0 Then
            Dim selectedItem As ListViewItem = lvStudents.SelectedItems(0)
            Dim studentID As String = selectedItem.SubItems(0).Text

            Dim result As DialogResult = MessageBox.Show("Are you sure you want to delete this student account?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
            If result = DialogResult.Yes Then
                Try
                    OpenConnection()

                    Dim deleteUserQuery As String = "DELETE FROM accounts WHERE username = @username"
                    Dim deleteUserCmd As New MySqlCommand(deleteUserQuery, conn)
                    deleteUserCmd.Parameters.AddWithValue("@username", studentID)
                    deleteUserCmd.ExecuteNonQuery()

                    ClearFields()

                    MessageBox.Show("Student deleted successfully!")
                Catch ex As Exception
                    MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Finally
                    CloseConnection()
                End Try
            Else
                MessageBox.Show("Please select a student to delete.")
            End If
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ClearFields()
    End Sub

    Private Sub ClearFields()
        txtStudentID.Clear()
        txtPassword.Clear()

        DisableFields()
    End Sub

    Private Sub UpdateButtonStates(studentID As String)
        If HasAccount(studentID) Then
            btnAdd.Enabled = False
            btnEdit.Enabled = True
            btnDelete.Enabled = True
        Else
            btnAdd.Enabled = True
            btnEdit.Enabled = False
            btnDelete.Enabled = False
        End If
    End Sub

    Private Sub DisableFields()
        txtStudentID.Enabled = False
        txtPassword.Enabled = False

        btnAdd.Enabled = False
        btnEdit.Enabled = False
        btnDelete.Enabled = False
    End Sub

    Private Sub lvStudents_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvStudents.SelectedIndexChanged
        If lvStudents.SelectedItems.Count > 0 Then
            Dim selectedItem As ListViewItem = lvStudents.SelectedItems(0)
            txtStudentID.Text = selectedItem.SubItems(0).Text

            UpdateButtonStates(txtStudentID.Text)
            txtPassword.Enabled = True
        End If
    End Sub

    Private Sub DASHBOARD_Click(sender As Object, e As EventArgs) Handles DASHBOARD.Click
        Dim anotherForm As New Admin_Form()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub COURSES_Click(sender As Object, e As EventArgs) Handles COURSES.Click
        Dim anotherForm As New Admin_Form_Manage_Courses()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub REPORT_Click(sender As Object, e As EventArgs) Handles REPORT.Click
        Dim anotherForm As New Admin_Form_View_Feedback()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub VIEWINSTRUCTORS_Click(sender As Object, e As EventArgs) Handles VIEWINSTRUCTORS.Click
        Dim anotherForm As New Admin_Form_Instructors()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub
End Class
