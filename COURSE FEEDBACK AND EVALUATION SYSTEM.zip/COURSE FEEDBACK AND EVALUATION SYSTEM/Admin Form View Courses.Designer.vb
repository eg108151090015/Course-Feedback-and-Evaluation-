﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_Form_Manage_Courses
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Admin_Form_Manage_Courses))
        btnClear = New Button()
        lvCourses = New ListView()
        txtCourseCode = New TextBox()
        Label4 = New Label()
        txtCourseName = New TextBox()
        txtCourseID = New TextBox()
        Label1 = New Label()
        adminMenu = New MenuStrip()
        HelloADMIN = New ToolStripMenuItem()
        DASHBOARD = New ToolStripMenuItem()
        COURSES = New ToolStripMenuItem()
        VIEWINSTRUCTORS = New ToolStripMenuItem()
        USERS = New ToolStripMenuItem()
        REPORT = New ToolStripMenuItem()
        Label2 = New Label()
        txtInstructorID = New TextBox()
        Label3 = New Label()
        adminMenu.SuspendLayout()
        SuspendLayout()
        ' 
        ' btnClear
        ' 
        btnClear.BackColor = Color.Maroon
        btnClear.FlatStyle = FlatStyle.Popup
        btnClear.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnClear.ForeColor = Color.White
        btnClear.Location = New Point(690, 448)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(130, 33)
        btnClear.TabIndex = 37
        btnClear.Text = "CLEAR"
        btnClear.UseVisualStyleBackColor = False
        ' 
        ' lvCourses
        ' 
        lvCourses.BorderStyle = BorderStyle.None
        lvCourses.FullRowSelect = True
        lvCourses.GridLines = True
        lvCourses.Location = New Point(254, 174)
        lvCourses.Name = "lvCourses"
        lvCourses.Size = New Size(566, 258)
        lvCourses.TabIndex = 33
        lvCourses.UseCompatibleStateImageBehavior = False
        lvCourses.View = View.Details
        ' 
        ' txtCourseCode
        ' 
        txtCourseCode.BackColor = Color.WhiteSmoke
        txtCourseCode.Enabled = False
        txtCourseCode.Font = New Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtCourseCode.ForeColor = Color.Black
        txtCourseCode.Location = New Point(581, 63)
        txtCourseCode.Name = "txtCourseCode"
        txtCourseCode.Size = New Size(239, 26)
        txtCourseCode.TabIndex = 31
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Transparent
        Label4.Font = New Font("OCR A Extended", 12F, FontStyle.Bold)
        Label4.ForeColor = Color.White
        Label4.Location = New Point(581, 41)
        Label4.Name = "Label4"
        Label4.Size = New Size(140, 17)
        Label4.TabIndex = 30
        Label4.Text = "Course Code:"
        ' 
        ' txtCourseName
        ' 
        txtCourseName.BackColor = Color.WhiteSmoke
        txtCourseName.Enabled = False
        txtCourseName.Font = New Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtCourseName.ForeColor = Color.Black
        txtCourseName.Location = New Point(254, 126)
        txtCourseName.Name = "txtCourseName"
        txtCourseName.Size = New Size(239, 26)
        txtCourseName.TabIndex = 27
        ' 
        ' txtCourseID
        ' 
        txtCourseID.BackColor = Color.WhiteSmoke
        txtCourseID.Enabled = False
        txtCourseID.Font = New Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtCourseID.ForeColor = Color.Black
        txtCourseID.Location = New Point(254, 63)
        txtCourseID.Name = "txtCourseID"
        txtCourseID.Size = New Size(239, 26)
        txtCourseID.TabIndex = 25
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("OCR A Extended", 12F, FontStyle.Bold)
        Label1.ForeColor = Color.White
        Label1.Location = New Point(254, 41)
        Label1.Name = "Label1"
        Label1.Size = New Size(118, 17)
        Label1.TabIndex = 24
        Label1.Text = "Course ID:"
        ' 
        ' adminMenu
        ' 
        adminMenu.BackColor = Color.FromArgb(CByte(64), CByte(0), CByte(0))
        adminMenu.Dock = DockStyle.Left
        adminMenu.Font = New Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        adminMenu.Items.AddRange(New ToolStripItem() {HelloADMIN, DASHBOARD, COURSES, VIEWINSTRUCTORS, USERS, REPORT})
        adminMenu.Location = New Point(0, 0)
        adminMenu.Name = "adminMenu"
        adminMenu.Size = New Size(196, 500)
        adminMenu.TabIndex = 23
        adminMenu.Text = "Admin Menu"
        ' 
        ' HelloADMIN
        ' 
        HelloADMIN.BackColor = Color.Transparent
        HelloADMIN.Font = New Font("OCR A Extended", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        HelloADMIN.ForeColor = Color.White
        HelloADMIN.ImageAlign = ContentAlignment.MiddleLeft
        HelloADMIN.Name = "HelloADMIN"
        HelloADMIN.Size = New Size(183, 27)
        HelloADMIN.Text = "Hello, #!"
        ' 
        ' DASHBOARD
        ' 
        DASHBOARD.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        DASHBOARD.ForeColor = Color.White
        DASHBOARD.Image = CType(resources.GetObject("DASHBOARD.Image"), Image)
        DASHBOARD.ImageAlign = ContentAlignment.MiddleLeft
        DASHBOARD.Name = "DASHBOARD"
        DASHBOARD.Size = New Size(183, 25)
        DASHBOARD.Text = "DASHBOARD"
        DASHBOARD.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' COURSES
        ' 
        COURSES.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        COURSES.ForeColor = Color.White
        COURSES.Image = CType(resources.GetObject("COURSES.Image"), Image)
        COURSES.ImageAlign = ContentAlignment.MiddleLeft
        COURSES.Name = "COURSES"
        COURSES.Size = New Size(183, 25)
        COURSES.Text = "VIEW COURSES"
        COURSES.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' VIEWINSTRUCTORS
        ' 
        VIEWINSTRUCTORS.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        VIEWINSTRUCTORS.ForeColor = Color.White
        VIEWINSTRUCTORS.Image = CType(resources.GetObject("VIEWINSTRUCTORS.Image"), Image)
        VIEWINSTRUCTORS.ImageAlign = ContentAlignment.MiddleLeft
        VIEWINSTRUCTORS.Name = "VIEWINSTRUCTORS"
        VIEWINSTRUCTORS.Size = New Size(183, 25)
        VIEWINSTRUCTORS.Text = "VIEW INSTRUCTORS"
        ' 
        ' USERS
        ' 
        USERS.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        USERS.ForeColor = Color.White
        USERS.Image = CType(resources.GetObject("USERS.Image"), Image)
        USERS.ImageAlign = ContentAlignment.MiddleLeft
        USERS.Name = "USERS"
        USERS.Size = New Size(183, 25)
        USERS.Text = "MANAGE USERS"
        USERS.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' REPORT
        ' 
        REPORT.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        REPORT.ForeColor = Color.White
        REPORT.Image = CType(resources.GetObject("REPORT.Image"), Image)
        REPORT.ImageAlign = ContentAlignment.MiddleLeft
        REPORT.Name = "REPORT"
        REPORT.Size = New Size(183, 25)
        REPORT.Text = "VIEW FEEDBACK"
        REPORT.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("OCR A Extended", 12F, FontStyle.Bold)
        Label2.ForeColor = Color.White
        Label2.Location = New Point(254, 104)
        Label2.Name = "Label2"
        Label2.Size = New Size(140, 17)
        Label2.TabIndex = 26
        Label2.Text = "Course Name:"
        ' 
        ' txtInstructorID
        ' 
        txtInstructorID.BackColor = Color.WhiteSmoke
        txtInstructorID.Enabled = False
        txtInstructorID.Font = New Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtInstructorID.ForeColor = Color.Black
        txtInstructorID.Location = New Point(581, 126)
        txtInstructorID.Name = "txtInstructorID"
        txtInstructorID.Size = New Size(239, 26)
        txtInstructorID.TabIndex = 39
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Transparent
        Label3.Font = New Font("OCR A Extended", 12F, FontStyle.Bold)
        Label3.ForeColor = Color.White
        Label3.Location = New Point(581, 104)
        Label3.Name = "Label3"
        Label3.Size = New Size(162, 17)
        Label3.TabIndex = 38
        Label3.Text = "Instructor ID:"
        ' 
        ' Admin_Form_Manage_Courses
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        BackgroundImage = My.Resources.Resources.wallp
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(900, 500)
        Controls.Add(txtInstructorID)
        Controls.Add(Label3)
        Controls.Add(btnClear)
        Controls.Add(lvCourses)
        Controls.Add(txtCourseCode)
        Controls.Add(Label4)
        Controls.Add(txtCourseName)
        Controls.Add(txtCourseID)
        Controls.Add(Label1)
        Controls.Add(adminMenu)
        Controls.Add(Label2)
        FormBorderStyle = FormBorderStyle.None
        MaximizeBox = False
        MaximumSize = New Size(900, 500)
        MinimumSize = New Size(900, 500)
        Name = "Admin_Form_Manage_Courses"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Admin Form Manage Courses"
        adminMenu.ResumeLayout(False)
        adminMenu.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents btnClear As Button
    Friend WithEvents lvCourses As ListView
    Friend WithEvents txtCourseCode As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtCourseName As TextBox
    Friend WithEvents txtCourseID As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents adminMenu As MenuStrip
    Friend WithEvents HelloADMIN As ToolStripMenuItem
    Friend WithEvents DASHBOARD As ToolStripMenuItem
    Friend WithEvents USERS As ToolStripMenuItem
    Friend WithEvents COURSES As ToolStripMenuItem
    Friend WithEvents REPORT As ToolStripMenuItem
    Friend WithEvents Label2 As Label
    Friend WithEvents VIEWINSTRUCTORS As ToolStripMenuItem
    Friend WithEvents txtInstructorID As TextBox
    Friend WithEvents Label3 As Label
End Class
