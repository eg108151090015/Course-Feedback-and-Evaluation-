﻿Imports MySql.Data.MySqlClient

Public Class Admin_Form_Manage_Courses

    Public Property Username As String

    Private Sub Admin_Form_Manage_Courses_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        HelloADMIN.Text = "Hello, " & Username & "!"

        lvCourses.View = View.Details
        lvCourses.Columns.Clear()
        lvCourses.Columns.Add("Course ID", 100, HorizontalAlignment.Left)
        lvCourses.Columns.Add("Course Name", 150, HorizontalAlignment.Left)
        lvCourses.Columns.Add("Course Code", 100, HorizontalAlignment.Left)
        lvCourses.Columns.Add("Instructor ID", 100, HorizontalAlignment.Left)

        DisplayAllCourses()
    End Sub

    Private Sub DisplayAllCourses()
        Try
            OpenConnection()

            Dim query As String = "SELECT course_id, course_name, course_code, instructor_id FROM Courses"
            Dim cmd As New MySqlCommand(query, conn)
            Dim reader As MySqlDataReader = cmd.ExecuteReader()

            lvCourses.Items.Clear()

            If reader.HasRows Then
                While reader.Read()
                    Dim item As New ListViewItem(reader("course_id").ToString())
                    item.SubItems.Add(reader("course_name").ToString())
                    item.SubItems.Add(reader("course_code").ToString())
                    item.SubItems.Add(reader("instructor_id").ToString())
                    lvCourses.Items.Add(item)
                End While
            Else
                MessageBox.Show("No courses found in the database.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

            reader.Close()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CloseConnection()
        End Try
    End Sub

    Private Sub lvCourses_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvCourses.SelectedIndexChanged
        If lvCourses.SelectedItems.Count > 0 Then
            Dim selectedItem As ListViewItem = lvCourses.SelectedItems(0)
            txtCourseID.Text = selectedItem.SubItems(0).Text
            txtCourseName.Text = selectedItem.SubItems(1).Text
            txtCourseCode.Text = selectedItem.SubItems(2).Text
            txtInstructorID.Text = selectedItem.SubItems(3).Text
        End If
    End Sub

    Private Sub DASHBOARD_Click(sender As Object, e As EventArgs) Handles DASHBOARD.Click
        Dim anotherForm As New Admin_Form()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub USERS_Click(sender As Object, e As EventArgs) Handles USERS.Click
        Dim anotherForm As New Admin_Form_Manage_Users()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub REPORT_Click(sender As Object, e As EventArgs) Handles REPORT.Click
        Dim anotherForm As New Admin_Form_View_Feedback()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub VIEWINSTRUCTORS_Click(sender As Object, e As EventArgs) Handles VIEWINSTRUCTORS.Click
        Dim anotherForm As New Admin_Form_Instructors()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtCourseID.Text = ""
        txtCourseName.Text = ""
        txtCourseCode.Text = ""
        txtInstructorID.Text = ""

        lvCourses.SelectedItems.Clear()
    End Sub
End Class