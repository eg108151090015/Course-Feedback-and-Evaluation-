﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_Form_View_Feedback
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Admin_Form_View_Feedback))
        btnClear = New Button()
        lvCourses = New ListView()
        Label1 = New Label()
        VIEWINSTRUCTORS = New ToolStripMenuItem()
        adminMenu = New MenuStrip()
        HelloADMIN = New ToolStripMenuItem()
        DASHBOARD = New ToolStripMenuItem()
        COURSES = New ToolStripMenuItem()
        USERS = New ToolStripMenuItem()
        REPORT = New ToolStripMenuItem()
        btnView = New Button()
        adminMenu.SuspendLayout()
        SuspendLayout()
        ' 
        ' btnClear
        ' 
        btnClear.BackColor = Color.Maroon
        btnClear.FlatStyle = FlatStyle.Popup
        btnClear.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        btnClear.ForeColor = Color.White
        btnClear.Location = New Point(391, 456)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(133, 33)
        btnClear.TabIndex = 39
        btnClear.Text = "CLEAR"
        btnClear.UseVisualStyleBackColor = False
        ' 
        ' lvCourses
        ' 
        lvCourses.FullRowSelect = True
        lvCourses.GridLines = True
        lvCourses.Location = New Point(252, 71)
        lvCourses.Name = "lvCourses"
        lvCourses.Size = New Size(566, 379)
        lvCourses.TabIndex = 35
        lvCourses.UseCompatibleStateImageBehavior = False
        lvCourses.View = View.Details
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("OCR A Extended", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.White
        Label1.Location = New Point(252, 34)
        Label1.Name = "Label1"
        Label1.Size = New Size(206, 23)
        Label1.TabIndex = 26
        Label1.Text = "Select Course:"
        ' 
        ' VIEWINSTRUCTORS
        ' 
        VIEWINSTRUCTORS.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        VIEWINSTRUCTORS.ForeColor = Color.White
        VIEWINSTRUCTORS.Image = CType(resources.GetObject("VIEWINSTRUCTORS.Image"), Image)
        VIEWINSTRUCTORS.ImageAlign = ContentAlignment.MiddleLeft
        VIEWINSTRUCTORS.Name = "VIEWINSTRUCTORS"
        VIEWINSTRUCTORS.Size = New Size(173, 24)
        VIEWINSTRUCTORS.Text = "VIEW INSTRUCTORS"
        ' 
        ' adminMenu
        ' 
        adminMenu.BackColor = Color.FromArgb(CByte(64), CByte(0), CByte(0))
        adminMenu.Dock = DockStyle.Left
        adminMenu.Font = New Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        adminMenu.Items.AddRange(New ToolStripItem() {HelloADMIN, DASHBOARD, COURSES, VIEWINSTRUCTORS, USERS, REPORT})
        adminMenu.Location = New Point(0, 0)
        adminMenu.Name = "adminMenu"
        adminMenu.Size = New Size(186, 500)
        adminMenu.TabIndex = 25
        adminMenu.Text = "Admin Menu"
        ' 
        ' HelloADMIN
        ' 
        HelloADMIN.BackColor = Color.Transparent
        HelloADMIN.Font = New Font("OCR A Extended", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        HelloADMIN.ForeColor = Color.White
        HelloADMIN.ImageAlign = ContentAlignment.MiddleLeft
        HelloADMIN.Name = "HelloADMIN"
        HelloADMIN.Size = New Size(173, 27)
        HelloADMIN.Text = "Hello, #!"
        ' 
        ' DASHBOARD
        ' 
        DASHBOARD.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        DASHBOARD.ForeColor = Color.White
        DASHBOARD.Image = CType(resources.GetObject("DASHBOARD.Image"), Image)
        DASHBOARD.ImageAlign = ContentAlignment.MiddleLeft
        DASHBOARD.Name = "DASHBOARD"
        DASHBOARD.Size = New Size(173, 24)
        DASHBOARD.Text = "DASHBOARD"
        DASHBOARD.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' COURSES
        ' 
        COURSES.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        COURSES.ForeColor = Color.White
        COURSES.Image = CType(resources.GetObject("COURSES.Image"), Image)
        COURSES.ImageAlign = ContentAlignment.MiddleLeft
        COURSES.Name = "COURSES"
        COURSES.Size = New Size(173, 24)
        COURSES.Text = "VIEW COURSES"
        COURSES.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' USERS
        ' 
        USERS.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        USERS.ForeColor = Color.White
        USERS.Image = CType(resources.GetObject("USERS.Image"), Image)
        USERS.ImageAlign = ContentAlignment.MiddleLeft
        USERS.Name = "USERS"
        USERS.Size = New Size(173, 24)
        USERS.Text = "MANAGE USERS"
        USERS.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' REPORT
        ' 
        REPORT.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        REPORT.ForeColor = Color.White
        REPORT.Image = CType(resources.GetObject("REPORT.Image"), Image)
        REPORT.ImageAlign = ContentAlignment.MiddleLeft
        REPORT.Name = "REPORT"
        REPORT.Size = New Size(173, 24)
        REPORT.Text = "VIEW FEEDBACK"
        REPORT.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' btnView
        ' 
        btnView.BackColor = Color.FromArgb(CByte(0), CByte(64), CByte(0))
        btnView.FlatStyle = FlatStyle.Popup
        btnView.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        btnView.ForeColor = Color.White
        btnView.Location = New Point(252, 456)
        btnView.Name = "btnView"
        btnView.Size = New Size(133, 33)
        btnView.TabIndex = 41
        btnView.Text = "VIEW"
        btnView.UseVisualStyleBackColor = False
        ' 
        ' Admin_Form_View_Feedback
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        BackgroundImage = My.Resources.Resources.wallp
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(900, 500)
        Controls.Add(btnView)
        Controls.Add(btnClear)
        Controls.Add(lvCourses)
        Controls.Add(Label1)
        Controls.Add(adminMenu)
        FormBorderStyle = FormBorderStyle.None
        MaximizeBox = False
        MaximumSize = New Size(900, 500)
        MinimumSize = New Size(900, 500)
        Name = "Admin_Form_View_Feedback"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Admin Form View Feedback"
        adminMenu.ResumeLayout(False)
        adminMenu.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents btnClear As Button
    Friend WithEvents lvCourses As ListView
    Friend WithEvents Label1 As Label
    Friend WithEvents VIEWINSTRUCTORS As ToolStripMenuItem
    Friend WithEvents adminMenu As MenuStrip
    Friend WithEvents HelloADMIN As ToolStripMenuItem
    Friend WithEvents DASHBOARD As ToolStripMenuItem
    Friend WithEvents COURSES As ToolStripMenuItem
    Friend WithEvents USERS As ToolStripMenuItem
    Friend WithEvents REPORT As ToolStripMenuItem
    Friend WithEvents btnView As Button
End Class
