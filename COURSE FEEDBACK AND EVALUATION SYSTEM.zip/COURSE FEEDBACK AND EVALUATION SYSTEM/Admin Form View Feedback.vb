﻿Imports MySql.Data.MySqlClient

Public Class Admin_Form_View_Feedback
    Public Property Username As String

    Dim answeredCourses As New Dictionary(Of String, Boolean)
    Private Sub Admin_Form_View_Feedback_Load(sender As Object, e As EventArgs) Handles Me.Load
        HelloADMIN.Text = "Hello, " & Username & "!"

        PopulateCourses()

        btnView.Enabled = False

        lvCourses.View = View.Details
        lvCourses.Columns.Clear()
        lvCourses.Columns.Add("Course Name", 200, HorizontalAlignment.Left)
        lvCourses.Columns.Add("Course Code", 100, HorizontalAlignment.Left)
        lvCourses.Columns.Add("Instructor", 150, HorizontalAlignment.Left)
    End Sub

    Private Sub PopulateCourses()
        Try
            OpenConnection()

            Dim query As String = "SELECT c.course_id, c.course_code, c.course_name, " &
                              "CONCAT(i.first_name, ' ', i.last_name) AS instructor_name " &
                              "FROM courses c " &
                              "JOIN instructors i ON c.instructor_id = i.instructor_id"
            Dim cmd As New MySqlCommand(query, conn)
            Dim reader As MySqlDataReader = cmd.ExecuteReader()

            lvCourses.Items.Clear()
            While reader.Read()
                Dim item As New ListViewItem(reader("course_name").ToString())
                item.SubItems.Add(reader("course_code").ToString())
                item.SubItems.Add(reader("instructor_name").ToString())
                item.Tag = reader("course_id")
                lvCourses.Items.Add(item)
            End While
            reader.Close()
        Catch ex As Exception
            MessageBox.Show("Error loading courses: " & ex.Message)
        Finally
            CloseConnection()
        End Try
    End Sub

    Private Sub DASHBOARD_Click(sender As Object, e As EventArgs) Handles DASHBOARD.Click
        Dim anotherForm As New Admin_Form()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub COURSES_Click(sender As Object, e As EventArgs) Handles COURSES.Click
        Dim anotherForm As New Admin_Form_Manage_Courses()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub VIEWINSTRUCTORS_Click(sender As Object, e As EventArgs) Handles VIEWINSTRUCTORS.Click
        Dim anotherForm As New Admin_Form_Instructors()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub USERS_Click(sender As Object, e As EventArgs) Handles USERS.Click
        Dim anotherForm As New Admin_Form_Manage_Users()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub lvCourses_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvCourses.SelectedIndexChanged
        btnView.Enabled = lvCourses.SelectedItems.Count > 0
    End Sub

    Private Sub btnView_Click(sender As Object, e As EventArgs) Handles btnView.Click
        If lvCourses.SelectedItems.Count <= 0 Then
            MessageBox.Show("Please select a course first.")
            Return
        End If

        Dim selectedCourse As String = lvCourses.SelectedItems(0).Text
        Dim selectedCourseID As Integer = Convert.ToInt32(lvCourses.SelectedItems(0).Tag)

        Dim ratingForm As New Overall_Rating(selectedCourseID, selectedCourse)
        ratingForm.Show()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lvCourses.SelectedItems.Clear()
        btnView.Enabled = False
    End Sub
End Class