﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_Form_Instructors
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Admin_Form_Instructors))
        adminMenu = New MenuStrip()
        HelloADMIN = New ToolStripMenuItem()
        DASHBOARD = New ToolStripMenuItem()
        COURSES = New ToolStripMenuItem()
        VIEWINSTRUCTORS = New ToolStripMenuItem()
        USERS = New ToolStripMenuItem()
        REPORT = New ToolStripMenuItem()
        Label2 = New Label()
        Label1 = New Label()
        txtInstructorID = New TextBox()
        txtFirstName = New TextBox()
        Label3 = New Label()
        txtLastName = New TextBox()
        Label4 = New Label()
        txtEmail = New TextBox()
        Label5 = New Label()
        lvInstructors = New ListView()
        btnClear = New Button()
        txtDepartment = New TextBox()
        Label6 = New Label()
        Label7 = New Label()
        adminMenu.SuspendLayout()
        SuspendLayout()
        ' 
        ' adminMenu
        ' 
        adminMenu.BackColor = Color.FromArgb(CByte(64), CByte(0), CByte(0))
        adminMenu.BackgroundImageLayout = ImageLayout.Zoom
        adminMenu.Dock = DockStyle.Left
        adminMenu.Font = New Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        adminMenu.Items.AddRange(New ToolStripItem() {HelloADMIN, DASHBOARD, COURSES, VIEWINSTRUCTORS, USERS, REPORT})
        adminMenu.Location = New Point(0, 0)
        adminMenu.Name = "adminMenu"
        adminMenu.Size = New Size(186, 500)
        adminMenu.TabIndex = 25
        adminMenu.Text = "Admin Menu"
        ' 
        ' HelloADMIN
        ' 
        HelloADMIN.BackColor = Color.Transparent
        HelloADMIN.Font = New Font("OCR A Extended", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        HelloADMIN.ForeColor = Color.White
        HelloADMIN.ImageAlign = ContentAlignment.MiddleLeft
        HelloADMIN.Name = "HelloADMIN"
        HelloADMIN.Size = New Size(173, 27)
        HelloADMIN.Text = "Hello, #!"
        ' 
        ' DASHBOARD
        ' 
        DASHBOARD.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        DASHBOARD.ForeColor = Color.White
        DASHBOARD.Image = CType(resources.GetObject("DASHBOARD.Image"), Image)
        DASHBOARD.ImageAlign = ContentAlignment.MiddleLeft
        DASHBOARD.Name = "DASHBOARD"
        DASHBOARD.Size = New Size(173, 24)
        DASHBOARD.Text = "DASHBOARD"
        DASHBOARD.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' COURSES
        ' 
        COURSES.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        COURSES.ForeColor = Color.White
        COURSES.Image = CType(resources.GetObject("COURSES.Image"), Image)
        COURSES.ImageAlign = ContentAlignment.MiddleLeft
        COURSES.Name = "COURSES"
        COURSES.Size = New Size(173, 24)
        COURSES.Text = "VIEW COURSES"
        COURSES.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' VIEWINSTRUCTORS
        ' 
        VIEWINSTRUCTORS.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        VIEWINSTRUCTORS.ForeColor = Color.White
        VIEWINSTRUCTORS.Image = CType(resources.GetObject("VIEWINSTRUCTORS.Image"), Image)
        VIEWINSTRUCTORS.ImageAlign = ContentAlignment.MiddleLeft
        VIEWINSTRUCTORS.Name = "VIEWINSTRUCTORS"
        VIEWINSTRUCTORS.Size = New Size(173, 24)
        VIEWINSTRUCTORS.Text = "VIEW INSTRUCTORS"
        ' 
        ' USERS
        ' 
        USERS.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        USERS.ForeColor = Color.White
        USERS.Image = CType(resources.GetObject("USERS.Image"), Image)
        USERS.ImageAlign = ContentAlignment.MiddleLeft
        USERS.Name = "USERS"
        USERS.Size = New Size(173, 24)
        USERS.Text = "MANAGE USERS"
        USERS.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' REPORT
        ' 
        REPORT.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        REPORT.ForeColor = Color.White
        REPORT.Image = CType(resources.GetObject("REPORT.Image"), Image)
        REPORT.ImageAlign = ContentAlignment.MiddleLeft
        REPORT.Name = "REPORT"
        REPORT.Size = New Size(173, 24)
        REPORT.Text = "VIEW FEEDBACK"
        REPORT.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("OCR A Extended", 12F, FontStyle.Bold)
        Label2.ForeColor = Color.White
        Label2.Location = New Point(246, 105)
        Label2.Name = "Label2"
        Label2.Size = New Size(129, 17)
        Label2.TabIndex = 28
        Label2.Text = "First Name:"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("OCR A Extended", 12F, FontStyle.Bold)
        Label1.ForeColor = Color.White
        Label1.Location = New Point(246, 42)
        Label1.Name = "Label1"
        Label1.Size = New Size(162, 17)
        Label1.TabIndex = 26
        Label1.Text = "Instructor ID:"
        ' 
        ' txtInstructorID
        ' 
        txtInstructorID.BackColor = Color.WhiteSmoke
        txtInstructorID.Enabled = False
        txtInstructorID.Font = New Font("Times New Roman", 11.25F, FontStyle.Bold)
        txtInstructorID.ForeColor = Color.White
        txtInstructorID.Location = New Point(246, 64)
        txtInstructorID.Name = "txtInstructorID"
        txtInstructorID.Size = New Size(239, 25)
        txtInstructorID.TabIndex = 27
        ' 
        ' txtFirstName
        ' 
        txtFirstName.BackColor = Color.WhiteSmoke
        txtFirstName.Enabled = False
        txtFirstName.Font = New Font("Times New Roman", 11.25F, FontStyle.Bold)
        txtFirstName.ForeColor = Color.White
        txtFirstName.Location = New Point(246, 127)
        txtFirstName.Name = "txtFirstName"
        txtFirstName.Size = New Size(239, 25)
        txtFirstName.TabIndex = 29
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Transparent
        Label3.Font = New Font("OCR A Extended", 12F, FontStyle.Bold)
        Label3.ForeColor = Color.White
        Label3.Location = New Point(248, 170)
        Label3.Name = "Label3"
        Label3.Size = New Size(118, 17)
        Label3.TabIndex = 30
        Label3.Text = "Last Name:"
        ' 
        ' txtLastName
        ' 
        txtLastName.BackColor = Color.WhiteSmoke
        txtLastName.Enabled = False
        txtLastName.Font = New Font("Times New Roman", 11.25F, FontStyle.Bold)
        txtLastName.ForeColor = Color.White
        txtLastName.Location = New Point(248, 192)
        txtLastName.Name = "txtLastName"
        txtLastName.Size = New Size(239, 25)
        txtLastName.TabIndex = 31
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Transparent
        Label4.Font = New Font("OCR A Extended", 12F, FontStyle.Bold)
        Label4.ForeColor = Color.White
        Label4.Location = New Point(573, 42)
        Label4.Name = "Label4"
        Label4.Size = New Size(74, 17)
        Label4.TabIndex = 32
        Label4.Text = "Email:"
        ' 
        ' txtEmail
        ' 
        txtEmail.BackColor = Color.WhiteSmoke
        txtEmail.Enabled = False
        txtEmail.Font = New Font("Times New Roman", 11.25F, FontStyle.Bold)
        txtEmail.ForeColor = Color.White
        txtEmail.Location = New Point(573, 64)
        txtEmail.Name = "txtEmail"
        txtEmail.Size = New Size(239, 25)
        txtEmail.TabIndex = 33
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.BackColor = Color.Transparent
        Label5.Font = New Font("OCR A Extended", 12F, FontStyle.Bold)
        Label5.ForeColor = Color.White
        Label5.Location = New Point(573, 105)
        Label5.Name = "Label5"
        Label5.Size = New Size(129, 17)
        Label5.TabIndex = 34
        Label5.Text = "Department:"
        ' 
        ' lvInstructors
        ' 
        lvInstructors.FullRowSelect = True
        lvInstructors.GridLines = True
        lvInstructors.Location = New Point(248, 240)
        lvInstructors.Name = "lvInstructors"
        lvInstructors.Size = New Size(564, 193)
        lvInstructors.TabIndex = 35
        lvInstructors.UseCompatibleStateImageBehavior = False
        lvInstructors.View = View.Details
        ' 
        ' btnClear
        ' 
        btnClear.BackColor = Color.Maroon
        btnClear.FlatStyle = FlatStyle.Popup
        btnClear.Font = New Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnClear.ForeColor = Color.White
        btnClear.Location = New Point(735, 450)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(130, 33)
        btnClear.TabIndex = 39
        btnClear.Text = "CLEAR"
        btnClear.UseVisualStyleBackColor = False
        ' 
        ' txtDepartment
        ' 
        txtDepartment.BackColor = Color.WhiteSmoke
        txtDepartment.Enabled = False
        txtDepartment.Font = New Font("Times New Roman", 11.25F, FontStyle.Bold)
        txtDepartment.ForeColor = Color.White
        txtDepartment.Location = New Point(573, 127)
        txtDepartment.Name = "txtDepartment"
        txtDepartment.Size = New Size(239, 25)
        txtDepartment.TabIndex = 41
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(516, -42)
        Label6.Name = "Label6"
        Label6.Size = New Size(89, 19)
        Label6.TabIndex = 28
        Label6.Text = "First Name:"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label7.Location = New Point(516, -105)
        Label7.Name = "Label7"
        Label7.Size = New Size(102, 19)
        Label7.TabIndex = 26
        Label7.Text = "Instructor ID:"
        ' 
        ' Admin_Form_Instructors
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Moccasin
        BackgroundImage = My.Resources.Resources.wallp
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(900, 500)
        Controls.Add(txtDepartment)
        Controls.Add(btnClear)
        Controls.Add(lvInstructors)
        Controls.Add(Label5)
        Controls.Add(txtEmail)
        Controls.Add(Label4)
        Controls.Add(txtLastName)
        Controls.Add(Label3)
        Controls.Add(txtFirstName)
        Controls.Add(txtInstructorID)
        Controls.Add(Label7)
        Controls.Add(Label1)
        Controls.Add(Label6)
        Controls.Add(adminMenu)
        Controls.Add(Label2)
        FormBorderStyle = FormBorderStyle.None
        MaximizeBox = False
        MaximumSize = New Size(900, 500)
        MinimumSize = New Size(900, 500)
        Name = "Admin_Form_Instructors"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Admin Form Instructors"
        adminMenu.ResumeLayout(False)
        adminMenu.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents adminMenu As MenuStrip
    Friend WithEvents HelloADMIN As ToolStripMenuItem
    Friend WithEvents DASHBOARD As ToolStripMenuItem
    Friend WithEvents USERS As ToolStripMenuItem
    Friend WithEvents COURSES As ToolStripMenuItem
    Friend WithEvents REPORT As ToolStripMenuItem
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtInstructorID As TextBox
    Friend WithEvents txtFirstName As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents lvInstructors As ListView
    Friend WithEvents btnClear As Button
    Friend WithEvents VIEWINSTRUCTORS As ToolStripMenuItem
    Friend WithEvents txtDepartment As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
End Class
