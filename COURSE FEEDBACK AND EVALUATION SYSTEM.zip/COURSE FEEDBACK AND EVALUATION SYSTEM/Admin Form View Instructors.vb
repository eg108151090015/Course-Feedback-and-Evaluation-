﻿Imports MySql.Data.MySqlClient

Public Class Admin_Form_Instructors

    Public Property Username As String

    Private Sub Admin_Form_Instructors_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        HelloADMIN.Text = "Hello, " & Username & "!"

        lvInstructors.View = View.Details
        lvInstructors.Columns.Clear()
        lvInstructors.Columns.Add("Instructor ID", 100, HorizontalAlignment.Left)
        lvInstructors.Columns.Add("First Name", 150, HorizontalAlignment.Left)
        lvInstructors.Columns.Add("Last Name", 150, HorizontalAlignment.Left)
        lvInstructors.Columns.Add("Email", 200, HorizontalAlignment.Left)
        lvInstructors.Columns.Add("Department", 150, HorizontalAlignment.Left)

        DisplayAllInstructors()
    End Sub

    Private Sub DisplayAllInstructors()
        Try
            OpenConnection()

            Dim query As String = "SELECT instructor_id, first_name, last_name, email, department FROM Instructors"
            Dim cmd As New MySqlCommand(query, conn)
            Dim reader As MySqlDataReader = cmd.ExecuteReader()

            lvInstructors.Items.Clear()

            If reader.HasRows Then
                While reader.Read()
                    Dim item As New ListViewItem(reader("instructor_id").ToString())
                    item.SubItems.Add(reader("first_name").ToString())
                    item.SubItems.Add(reader("last_name").ToString())
                    item.SubItems.Add(reader("email").ToString())
                    item.SubItems.Add(reader("department").ToString())
                    lvInstructors.Items.Add(item)
                End While
            Else
                MessageBox.Show("No instructors found in the database.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

            reader.Close()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CloseConnection()
        End Try
    End Sub

    Private Sub lvInstructors_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvInstructors.SelectedIndexChanged
        If lvInstructors.SelectedItems.Count > 0 Then
            Dim selectedItem As ListViewItem = lvInstructors.SelectedItems(0)
            txtInstructorID.Text = selectedItem.SubItems(0).Text
            txtFirstName.Text = selectedItem.SubItems(1).Text
            txtLastName.Text = selectedItem.SubItems(2).Text
            txtEmail.Text = selectedItem.SubItems(3).Text
            txtDepartment.Text = selectedItem.SubItems(4).Text
        End If
    End Sub

    Private Sub DASHBOARD_Click(sender As Object, e As EventArgs) Handles DASHBOARD.Click
        Dim anotherForm As New Admin_Form()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub USERS_Click(sender As Object, e As EventArgs) Handles USERS.Click
        Dim anotherForm As New Admin_Form_Manage_Users()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub COURSES_Click(sender As Object, e As EventArgs) Handles COURSES.Click
        Dim anotherForm As New Admin_Form_Manage_Courses()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub REPORT_Click(sender As Object, e As EventArgs) Handles REPORT.Click
        Dim anotherForm As New Admin_Form_View_Feedback()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtInstructorID.Text = ""
        txtFirstName.Text = ""
        txtLastName.Text = ""
        txtEmail.Text = ""
        txtDepartment.Text = ""

        lvInstructors.SelectedItems.Clear()
    End Sub


End Class