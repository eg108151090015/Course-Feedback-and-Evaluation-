﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_Form
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Admin_Form))
        adminMenu = New MenuStrip()
        HelloADMIN = New ToolStripMenuItem()
        DASHBOARD = New ToolStripMenuItem()
        COURSES = New ToolStripMenuItem()
        VIEWINSTRUCTORS = New ToolStripMenuItem()
        USERS = New ToolStripMenuItem()
        REPORT = New ToolStripMenuItem()
        pCourses = New Panel()
        PictureBox1 = New PictureBox()
        Label1 = New Label()
        lblTotalCourses = New Label()
        pInstructors = New Panel()
        PictureBox2 = New PictureBox()
        Label2 = New Label()
        lblTotalInstructors = New Label()
        pStudents = New Panel()
        PictureBox3 = New PictureBox()
        Label3 = New Label()
        lblTotalStudents = New Label()
        pFeedback = New Panel()
        PictureBox4 = New PictureBox()
        Label4 = New Label()
        lblTotalFeedback = New Label()
        btnLogout = New Button()
        adminMenu.SuspendLayout()
        pCourses.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        pInstructors.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        pStudents.SuspendLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        pFeedback.SuspendLayout()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' adminMenu
        ' 
        adminMenu.BackColor = Color.FromArgb(CByte(64), CByte(0), CByte(0))
        adminMenu.Dock = DockStyle.Left
        adminMenu.Font = New Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        adminMenu.Items.AddRange(New ToolStripItem() {HelloADMIN, DASHBOARD, COURSES, VIEWINSTRUCTORS, USERS, REPORT})
        adminMenu.Location = New Point(0, 0)
        adminMenu.Name = "adminMenu"
        adminMenu.Size = New Size(186, 500)
        adminMenu.TabIndex = 0
        adminMenu.Text = "Admin Menu"
        ' 
        ' HelloADMIN
        ' 
        HelloADMIN.BackColor = Color.Transparent
        HelloADMIN.Font = New Font("OCR A Extended", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        HelloADMIN.ForeColor = Color.White
        HelloADMIN.ImageAlign = ContentAlignment.MiddleLeft
        HelloADMIN.Name = "HelloADMIN"
        HelloADMIN.Size = New Size(173, 27)
        HelloADMIN.Text = "Hello, #!"
        ' 
        ' DASHBOARD
        ' 
        DASHBOARD.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        DASHBOARD.ForeColor = Color.White
        DASHBOARD.Image = CType(resources.GetObject("DASHBOARD.Image"), Image)
        DASHBOARD.ImageAlign = ContentAlignment.MiddleLeft
        DASHBOARD.Name = "DASHBOARD"
        DASHBOARD.Size = New Size(173, 24)
        DASHBOARD.Text = "DASHBOARD"
        DASHBOARD.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' COURSES
        ' 
        COURSES.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        COURSES.ForeColor = Color.White
        COURSES.Image = CType(resources.GetObject("COURSES.Image"), Image)
        COURSES.ImageAlign = ContentAlignment.MiddleLeft
        COURSES.Name = "COURSES"
        COURSES.Size = New Size(173, 24)
        COURSES.Text = "VIEW COURSES"
        COURSES.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' VIEWINSTRUCTORS
        ' 
        VIEWINSTRUCTORS.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        VIEWINSTRUCTORS.ForeColor = Color.White
        VIEWINSTRUCTORS.Image = CType(resources.GetObject("VIEWINSTRUCTORS.Image"), Image)
        VIEWINSTRUCTORS.ImageAlign = ContentAlignment.MiddleLeft
        VIEWINSTRUCTORS.Name = "VIEWINSTRUCTORS"
        VIEWINSTRUCTORS.Size = New Size(173, 24)
        VIEWINSTRUCTORS.Text = "VIEW INSTRUCTORS"
        ' 
        ' USERS
        ' 
        USERS.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        USERS.ForeColor = Color.White
        USERS.Image = CType(resources.GetObject("USERS.Image"), Image)
        USERS.ImageAlign = ContentAlignment.MiddleLeft
        USERS.Name = "USERS"
        USERS.Size = New Size(173, 24)
        USERS.Text = "MANAGE USERS"
        USERS.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' REPORT
        ' 
        REPORT.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        REPORT.ForeColor = Color.White
        REPORT.Image = CType(resources.GetObject("REPORT.Image"), Image)
        REPORT.ImageAlign = ContentAlignment.MiddleLeft
        REPORT.Name = "REPORT"
        REPORT.Size = New Size(173, 24)
        REPORT.Text = "VIEW FEEDBACK"
        REPORT.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' pCourses
        ' 
        pCourses.BackColor = Color.FromArgb(CByte(64), CByte(0), CByte(0))
        pCourses.BorderStyle = BorderStyle.FixedSingle
        pCourses.Controls.Add(PictureBox1)
        pCourses.Controls.Add(Label1)
        pCourses.Controls.Add(lblTotalCourses)
        pCourses.Location = New Point(226, 76)
        pCourses.Name = "pCourses"
        pCourses.Size = New Size(200, 100)
        pCourses.TabIndex = 1
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.book
        PictureBox1.Location = New Point(116, 3)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(83, 92)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 2
        PictureBox1.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold)
        Label1.ForeColor = Color.White
        Label1.Location = New Point(3, 64)
        Label1.Name = "Label1"
        Label1.Size = New Size(107, 21)
        Label1.TabIndex = 1
        Label1.Text = "Total Courses"
        ' 
        ' lblTotalCourses
        ' 
        lblTotalCourses.AutoSize = True
        lblTotalCourses.Font = New Font("Segoe UI Black", 12F, FontStyle.Bold)
        lblTotalCourses.ForeColor = Color.White
        lblTotalCourses.Location = New Point(50, 24)
        lblTotalCourses.Name = "lblTotalCourses"
        lblTotalCourses.Size = New Size(60, 21)
        lblTotalCourses.TabIndex = 0
        lblTotalCourses.Text = "Label1"
        ' 
        ' pInstructors
        ' 
        pInstructors.BackColor = Color.FromArgb(CByte(64), CByte(0), CByte(0))
        pInstructors.BorderStyle = BorderStyle.FixedSingle
        pInstructors.Controls.Add(PictureBox2)
        pInstructors.Controls.Add(Label2)
        pInstructors.Controls.Add(lblTotalInstructors)
        pInstructors.Location = New Point(451, 76)
        pInstructors.Name = "pInstructors"
        pInstructors.Size = New Size(200, 100)
        pInstructors.TabIndex = 3
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), Image)
        PictureBox2.Location = New Point(128, 24)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(59, 50)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 2
        PictureBox2.TabStop = False
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        Label2.ForeColor = Color.White
        Label2.Location = New Point(3, 65)
        Label2.Name = "Label2"
        Label2.Size = New Size(125, 20)
        Label2.TabIndex = 1
        Label2.Text = "Total Instructors"
        ' 
        ' lblTotalInstructors
        ' 
        lblTotalInstructors.AutoSize = True
        lblTotalInstructors.Font = New Font("Segoe UI Black", 12F, FontStyle.Bold)
        lblTotalInstructors.ForeColor = Color.White
        lblTotalInstructors.Location = New Point(49, 24)
        lblTotalInstructors.Name = "lblTotalInstructors"
        lblTotalInstructors.Size = New Size(60, 21)
        lblTotalInstructors.TabIndex = 0
        lblTotalInstructors.Text = "Label1"
        ' 
        ' pStudents
        ' 
        pStudents.BackColor = Color.FromArgb(CByte(64), CByte(0), CByte(0))
        pStudents.BorderStyle = BorderStyle.FixedSingle
        pStudents.Controls.Add(PictureBox3)
        pStudents.Controls.Add(Label3)
        pStudents.Controls.Add(lblTotalStudents)
        pStudents.Location = New Point(674, 76)
        pStudents.Name = "pStudents"
        pStudents.Size = New Size(200, 100)
        pStudents.TabIndex = 4
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), Image)
        PictureBox3.Location = New Point(128, 24)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(59, 50)
        PictureBox3.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox3.TabIndex = 2
        PictureBox3.TabStop = False
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        Label3.ForeColor = Color.White
        Label3.Location = New Point(3, 65)
        Label3.Name = "Label3"
        Label3.Size = New Size(110, 20)
        Label3.TabIndex = 1
        Label3.Text = "Total Students"
        ' 
        ' lblTotalStudents
        ' 
        lblTotalStudents.AutoSize = True
        lblTotalStudents.Font = New Font("Segoe UI Black", 12F, FontStyle.Bold)
        lblTotalStudents.ForeColor = Color.White
        lblTotalStudents.Location = New Point(42, 24)
        lblTotalStudents.Name = "lblTotalStudents"
        lblTotalStudents.Size = New Size(60, 21)
        lblTotalStudents.TabIndex = 0
        lblTotalStudents.Text = "Label1"
        ' 
        ' pFeedback
        ' 
        pFeedback.BackColor = Color.FromArgb(CByte(64), CByte(0), CByte(0))
        pFeedback.BorderStyle = BorderStyle.FixedSingle
        pFeedback.Controls.Add(PictureBox4)
        pFeedback.Controls.Add(Label4)
        pFeedback.Controls.Add(lblTotalFeedback)
        pFeedback.Location = New Point(226, 200)
        pFeedback.Name = "pFeedback"
        pFeedback.Size = New Size(200, 100)
        pFeedback.TabIndex = 5
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), Image)
        PictureBox4.Location = New Point(128, 24)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(59, 50)
        PictureBox4.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox4.TabIndex = 2
        PictureBox4.TabStop = False
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        Label4.ForeColor = Color.White
        Label4.Location = New Point(3, 69)
        Label4.Name = "Label4"
        Label4.Size = New Size(113, 20)
        Label4.TabIndex = 1
        Label4.Text = "Total Feedback"
        ' 
        ' lblTotalFeedback
        ' 
        lblTotalFeedback.AutoSize = True
        lblTotalFeedback.Font = New Font("Segoe UI Black", 12F, FontStyle.Bold)
        lblTotalFeedback.ForeColor = Color.White
        lblTotalFeedback.Location = New Point(50, 24)
        lblTotalFeedback.Name = "lblTotalFeedback"
        lblTotalFeedback.Size = New Size(60, 21)
        lblTotalFeedback.TabIndex = 0
        lblTotalFeedback.Text = "Label1"
        ' 
        ' btnLogout
        ' 
        btnLogout.BackColor = Color.Maroon
        btnLogout.FlatStyle = FlatStyle.Popup
        btnLogout.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnLogout.ForeColor = Color.White
        btnLogout.Location = New Point(784, 455)
        btnLogout.Name = "btnLogout"
        btnLogout.Size = New Size(104, 33)
        btnLogout.TabIndex = 21
        btnLogout.Text = "LOGOUT"
        btnLogout.UseVisualStyleBackColor = False
        ' 
        ' Admin_Form
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Moccasin
        BackgroundImage = My.Resources.Resources.wallp
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(900, 500)
        Controls.Add(btnLogout)
        Controls.Add(pFeedback)
        Controls.Add(pStudents)
        Controls.Add(pInstructors)
        Controls.Add(pCourses)
        Controls.Add(adminMenu)
        ForeColor = Color.White
        FormBorderStyle = FormBorderStyle.None
        MainMenuStrip = adminMenu
        MaximizeBox = False
        MaximumSize = New Size(900, 500)
        MinimumSize = New Size(900, 500)
        Name = "Admin_Form"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Admin Form Dashboard"
        adminMenu.ResumeLayout(False)
        adminMenu.PerformLayout()
        pCourses.ResumeLayout(False)
        pCourses.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        pInstructors.ResumeLayout(False)
        pInstructors.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        pStudents.ResumeLayout(False)
        pStudents.PerformLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        pFeedback.ResumeLayout(False)
        pFeedback.PerformLayout()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents adminMenu As MenuStrip
    Friend WithEvents USERS As ToolStripMenuItem
    Friend WithEvents COURSES As ToolStripMenuItem
    Friend WithEvents REPORT As ToolStripMenuItem
    Friend WithEvents DASHBOARD As ToolStripMenuItem
    Friend WithEvents HelloADMIN As ToolStripMenuItem
    Friend WithEvents pCourses As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents lblTotalCourses As Label
    Friend WithEvents pInstructors As Panel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents lblTotalInstructors As Label
    Friend WithEvents pStudents As Panel
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents lblTotalStudents As Label
    Friend WithEvents pFeedback As Panel
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents lblTotalFeedback As Label
    Friend WithEvents VIEWINSTRUCTORS As ToolStripMenuItem
    Friend WithEvents btnLogout As Button
End Class
