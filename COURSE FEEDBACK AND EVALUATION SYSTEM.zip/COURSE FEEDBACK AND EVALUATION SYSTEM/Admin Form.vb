﻿Imports MySql.Data.MySqlClient

Public Class Admin_Form

    Public Property Username As String

    Private Sub AdminForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        HelloADMIN.Text = "Hello, " & Username & "!"
    End Sub


    Private Sub Admin_Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        UpdateTotals()
    End Sub

    Private Sub USERS_Click(sender As Object, e As EventArgs) Handles USERS.Click
        Dim anotherForm As New Admin_Form_Manage_Users()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub COURSES_Click(sender As Object, e As EventArgs) Handles COURSES.Click
        Dim anotherForm As New Admin_Form_Manage_Courses()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub REPORT_Click(sender As Object, e As EventArgs) Handles REPORT.Click
        Dim anotherForm As New Admin_Form_View_Feedback()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub pCourses_Click(sender As Object, e As EventArgs) Handles pCourses.Click
        Dim anotherForm As New Admin_Form_Manage_Courses()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub pInstructors_Click(sender As Object, e As EventArgs) Handles pInstructors.Click
        Dim anotherForm As New Admin_Form_Instructors()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub UpdateTotals()
        Dim totalCourses As Integer = GetTotalCourses()
        Dim totalInstructors As Integer = GetTotalInstructors()
        Dim totalStudents As Integer = GetTotalStudents()
        Dim totalFeedback As Integer = GetTotalFeedback()

        lblTotalCourses.Text = totalCourses.ToString()
        lblTotalInstructors.Text = totalInstructors.ToString()
        lblTotalStudents.Text = totalStudents.ToString()
        lblTotalFeedback.Text = totalFeedback.ToString()
    End Sub

    Private Sub pStudents_Click(sender As Object, e As EventArgs) Handles pStudents.Click
        Dim anotherForm As New Admin_Form_Manage_Users()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub pFeedback_Click(sender As Object, e As EventArgs) Handles pFeedback.Click
        Dim anotherForm As New Admin_Form_View_Feedback()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Function GetTotalCourses() As Integer
        Dim total As Integer = 0
        Try
            OpenConnection()

            Dim query As String = "SELECT COUNT(*) FROM courses"
            Dim cmd As New MySqlCommand(query, conn)
            total = Convert.ToInt32(cmd.ExecuteScalar())
        Catch ex As Exception
            MessageBox.Show("Error calculating total courses: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CloseConnection()
        End Try
        Return total
    End Function

    Private Function GetTotalInstructors() As Integer
        Dim total As Integer = 0
        Try
            OpenConnection()

            Dim query As String = "SELECT COUNT(*) FROM instructors"
            Dim cmd As New MySqlCommand(query, conn)
            total = Convert.ToInt32(cmd.ExecuteScalar())
        Catch ex As Exception
            MessageBox.Show("Error calculating total instructors: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CloseConnection()
        End Try
        Return total
    End Function

    Private Function GetTotalStudents() As Integer
        Dim total As Integer = 0
        Try
            OpenConnection()

            Dim query As String = "SELECT COUNT(*) FROM students WHERE student_id <> 0"
            Dim cmd As New MySqlCommand(query, conn)
            total = Convert.ToInt32(cmd.ExecuteScalar())
        Catch ex As Exception
            MessageBox.Show("Error calculating total students: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CloseConnection()
        End Try
        Return total
    End Function


    Private Function GetTotalFeedback() As Integer
        Dim total As Integer = 0
        Try
            OpenConnection()

            Dim query As String = "SELECT COUNT(*) FROM feedback_responses"
            Dim cmd As New MySqlCommand(query, conn)
            total = Convert.ToInt32(cmd.ExecuteScalar())
        Catch ex As Exception
            MessageBox.Show("Error calculating total feedbacks: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CloseConnection()
        End Try
        Return total
    End Function

    Private Sub VIEWINSTRUCTORS_Click(sender As Object, e As EventArgs) Handles VIEWINSTRUCTORS.Click
        Dim anotherForm As New Admin_Form_Instructors()
        anotherForm.Username = Me.Username
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        OpenConnection()
        LoginForm.txtUserName.Text = ""
        LoginForm.txtPassword.Text = ""
        LoginForm.cbShowHidePassword.Checked = False

        LoginForm.Show()
        Me.Hide()
    End Sub
End Class