﻿Imports MySql.Data

Imports MySql.Data.MySqlClient

Module Modulel

    Private connectionString As String = "Server=127.0.0.1;Database=coursefeedbackandevaluationsystem;Uid=root;Pwd=;"

    Public conn As MySqlConnection = New MySqlConnection(connectionString)

    Public Function OpenConnection() As MySqlConnection
        Try
            If conn.State = ConnectionState.Closed Then
                conn.Open()
            End If
        Catch ex As MySqlException
            MessageBox.Show("Error opening connection:" & ex.Message)
        End Try
        Return conn
    End Function

    Public Sub CloseConnection()
        Try
            If conn.State = ConnectionState.Open Then
                conn.Close()
            End If
        Catch ex As MySqlException
            MessageBox.Show("Error closing connection: " & ex.Message)
        End Try
    End Sub
End Module