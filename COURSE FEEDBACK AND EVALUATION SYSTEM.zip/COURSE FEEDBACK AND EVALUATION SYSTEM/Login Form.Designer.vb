﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class LoginForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(LoginForm))
        PictureBox1 = New PictureBox()
        btnLogin = New Button()
        txtPassword = New TextBox()
        lblPassword = New Label()
        txtUserName = New TextBox()
        lblUsername = New Label()
        title = New Label()
        Label1 = New Label()
        Label2 = New Label()
        PictureBox2 = New PictureBox()
        btnExit = New Button()
        Label3 = New Label()
        Label4 = New Label()
        cbShowHidePassword = New CheckBox()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(12, 12)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(85, 71)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 0
        PictureBox1.TabStop = False
        ' 
        ' btnLogin
        ' 
        btnLogin.BackColor = Color.White
        btnLogin.FlatStyle = FlatStyle.Popup
        btnLogin.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnLogin.ForeColor = Color.Maroon
        btnLogin.Location = New Point(51, 358)
        btnLogin.Name = "btnLogin"
        btnLogin.Size = New Size(190, 44)
        btnLogin.TabIndex = 4
        btnLogin.Text = "LOGIN"
        btnLogin.UseVisualStyleBackColor = False
        ' 
        ' txtPassword
        ' 
        txtPassword.BackColor = Color.DimGray
        txtPassword.Font = New Font("Segoe UI Semibold", 11.25F, FontStyle.Bold)
        txtPassword.ForeColor = Color.Black
        txtPassword.Location = New Point(51, 283)
        txtPassword.Multiline = True
        txtPassword.Name = "txtPassword"
        txtPassword.PasswordChar = "*"c
        txtPassword.Size = New Size(279, 31)
        txtPassword.TabIndex = 3
        ' 
        ' lblPassword
        ' 
        lblPassword.AutoSize = True
        lblPassword.BackColor = Color.Transparent
        lblPassword.Font = New Font("Franklin Gothic Demi Cond", 11.25F)
        lblPassword.ForeColor = Color.White
        lblPassword.Location = New Point(51, 260)
        lblPassword.Name = "lblPassword"
        lblPassword.Size = New Size(76, 20)
        lblPassword.TabIndex = 2
        lblPassword.Text = "PASSWORD"
        ' 
        ' txtUserName
        ' 
        txtUserName.BackColor = Color.DimGray
        txtUserName.Font = New Font("Segoe UI Semibold", 11.25F, FontStyle.Bold)
        txtUserName.ForeColor = Color.Black
        txtUserName.Location = New Point(51, 213)
        txtUserName.Multiline = True
        txtUserName.Name = "txtUserName"
        txtUserName.Size = New Size(279, 31)
        txtUserName.TabIndex = 1
        ' 
        ' lblUsername
        ' 
        lblUsername.AutoSize = True
        lblUsername.BackColor = Color.Transparent
        lblUsername.Font = New Font("Franklin Gothic Demi Cond", 11.25F)
        lblUsername.ForeColor = Color.White
        lblUsername.Location = New Point(51, 190)
        lblUsername.Name = "lblUsername"
        lblUsername.Size = New Size(158, 20)
        lblUsername.TabIndex = 0
        lblUsername.Text = "SIGN IN WITH USER NAME"
        ' 
        ' title
        ' 
        title.AutoSize = True
        title.BackColor = Color.Transparent
        title.Font = New Font("OCR A Extended", 24F, FontStyle.Bold)
        title.ForeColor = Color.White
        title.Location = New Point(422, 209)
        title.Name = "title"
        title.Size = New Size(315, 35)
        title.TabIndex = 2
        title.Text = "COURSE FEEDBACK"
        title.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("OCR A Extended", 26.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.White
        Label1.Location = New Point(114, 41)
        Label1.Name = "Label1"
        Label1.Size = New Size(105, 37)
        Label1.TabIndex = 3
        Label1.Text = "SIGN"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("OCR A Extended", 26.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.ForeColor = Color.Maroon
        Label2.Location = New Point(209, 41)
        Label2.Name = "Label2"
        Label2.Size = New Size(61, 37)
        Label2.TabIndex = 5
        Label2.Text = "IN"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackColor = Color.Transparent
        PictureBox2.Image = My.Resources.Resources._286525063_106641922075024_2189105170410225240_n_Photoroom
        PictureBox2.Location = New Point(715, 423)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(73, 65)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 6
        PictureBox2.TabStop = False
        ' 
        ' btnExit
        ' 
        btnExit.BackColor = Color.Maroon
        btnExit.FlatStyle = FlatStyle.Popup
        btnExit.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnExit.ForeColor = Color.White
        btnExit.Location = New Point(715, 12)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(73, 27)
        btnExit.TabIndex = 8
        btnExit.Text = "EXIT"
        btnExit.UseVisualStyleBackColor = False
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Transparent
        Label3.Font = New Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = Color.White
        Label3.Location = New Point(450, 298)
        Label3.Name = "Label3"
        Label3.Size = New Size(255, 34)
        Label3.TabIndex = 9
        Label3.Text = "Hi there, i hope you're having a good day." & vbCrLf & "                       Please Log In."
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Transparent
        Label4.Font = New Font("OCR A Extended", 24F, FontStyle.Bold)
        Label4.ForeColor = Color.Maroon
        Label4.Location = New Point(397, 247)
        Label4.Name = "Label4"
        Label4.Size = New Size(355, 35)
        Label4.TabIndex = 10
        Label4.Text = "EVALUATION SYSTEM"
        Label4.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' cbShowHidePassword
        ' 
        cbShowHidePassword.AutoSize = True
        cbShowHidePassword.BackColor = Color.Transparent
        cbShowHidePassword.Font = New Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        cbShowHidePassword.ForeColor = Color.WhiteSmoke
        cbShowHidePassword.Location = New Point(205, 320)
        cbShowHidePassword.Name = "cbShowHidePassword"
        cbShowHidePassword.Size = New Size(125, 21)
        cbShowHidePassword.TabIndex = 12
        cbShowHidePassword.Text = "Show Password."
        cbShowHidePassword.UseVisualStyleBackColor = False
        ' 
        ' LoginForm
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Moccasin
        BackgroundImage = My.Resources.Resources.wallp
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(800, 500)
        Controls.Add(cbShowHidePassword)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(btnExit)
        Controls.Add(PictureBox2)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(btnLogin)
        Controls.Add(title)
        Controls.Add(lblPassword)
        Controls.Add(txtPassword)
        Controls.Add(lblUsername)
        Controls.Add(PictureBox1)
        Controls.Add(txtUserName)
        FormBorderStyle = FormBorderStyle.None
        MaximizeBox = False
        MaximumSize = New Size(800, 500)
        MinimumSize = New Size(800, 500)
        Name = "LoginForm"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Login Form"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents title As Label
    Friend WithEvents txtUserName As TextBox
    Friend WithEvents lblUsername As Label
    Friend WithEvents btnLogin As Button
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents lblPassword As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents btnExit As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents cbShowHidePassword As CheckBox

End Class
