﻿Imports MySql.Data.MySqlClient

Public Class LoginForm

    Public LoggedInUsername As String
    Public LoggedInFirstName As String

    Public LoggedInStudentID As String

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Try
            Dim query As String = "SELECT u.username, s.first_name, u.role " &
                                  "FROM accounts u " &
                                  "LEFT JOIN students s ON u.username = s.student_id " &
                                  "WHERE u.username = @username AND u.password = @password"
            Dim cmd As New MySqlCommand(query, conn)

            cmd.Parameters.AddWithValue("@username", txtUserName.Text)
            cmd.Parameters.AddWithValue("@password", txtPassword.Text)

            Dim reader As MySqlDataReader = cmd.ExecuteReader()

            If reader.HasRows Then
                reader.Read()
                LoggedInStudentID = reader("username").ToString()
                LoggedInUsername = reader("username").ToString()
                LoggedInFirstName = If(IsDBNull(reader("first_name")), "", reader("first_name").ToString())
                Dim role As String = reader("role").ToString()
                reader.Close()

                If role = "admin" Then
                    Dim adminForm As New Admin_Form()
                    adminForm.Username = LoggedInUsername
                    adminForm.Show()
                    Me.Hide()
                ElseIf role = "student" Then
                    Dim studentForm As New Student_Form()
                    studentForm.LoggedInStudentID = LoggedInStudentID
                    studentForm.FirstName = LoggedInFirstName
                    studentForm.Show()
                    Me.Hide()
                End If

                Me.Hide()
            Else
                MessageBox.Show("Invalid username or password.", "Invalid Entry", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                reader.Close()
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            CloseConnection()
        End Try
    End Sub

    Private Sub LoginForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        OpenConnection()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub cbShowHidePassword_CheckedChanged(sender As Object, e As EventArgs) Handles cbShowHidePassword.CheckedChanged
        If (cbShowHidePassword.Checked) Then
            txtPassword.PasswordChar = ""
        Else
            txtPassword.PasswordChar = "*"
        End If
    End Sub
End Class