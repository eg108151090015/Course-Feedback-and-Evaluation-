﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Overall_Rating
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        lblCourseTitle = New Label()
        lblOverallRating = New Label()
        btnExit = New Button()
        Panel1 = New Panel()
        Panel3 = New Panel()
        Panel2 = New Panel()
        Panel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' lblCourseTitle
        ' 
        lblCourseTitle.AutoSize = True
        lblCourseTitle.BackColor = Color.Transparent
        lblCourseTitle.Font = New Font("OCR A Extended", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblCourseTitle.ForeColor = Color.White
        lblCourseTitle.Location = New Point(44, 208)
        lblCourseTitle.Name = "lblCourseTitle"
        lblCourseTitle.Size = New Size(63, 17)
        lblCourseTitle.TabIndex = 0
        lblCourseTitle.Text = "Label"
        ' 
        ' lblOverallRating
        ' 
        lblOverallRating.AutoSize = True
        lblOverallRating.BackColor = Color.Transparent
        lblOverallRating.Font = New Font("OCR A Extended", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblOverallRating.ForeColor = Color.White
        lblOverallRating.Location = New Point(44, 301)
        lblOverallRating.Name = "lblOverallRating"
        lblOverallRating.Size = New Size(63, 17)
        lblOverallRating.TabIndex = 1
        lblOverallRating.Text = "Label"
        ' 
        ' btnExit
        ' 
        btnExit.BackColor = Color.Maroon
        btnExit.FlatStyle = FlatStyle.Popup
        btnExit.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnExit.ForeColor = Color.White
        btnExit.Location = New Point(523, 463)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(75, 30)
        btnExit.TabIndex = 2
        btnExit.Text = "BACK"
        btnExit.UseVisualStyleBackColor = False
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Black
        Panel1.Controls.Add(lblOverallRating)
        Panel1.Controls.Add(lblCourseTitle)
        Panel1.Controls.Add(Panel3)
        Panel1.Controls.Add(Panel2)
        Panel1.Controls.Add(btnExit)
        Panel1.Location = New Point(-2, -5)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(612, 509)
        Panel1.TabIndex = 3
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Panel3.Location = New Point(44, 321)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(480, 10)
        Panel3.TabIndex = 4
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Panel2.Location = New Point(44, 228)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(480, 10)
        Panel2.TabIndex = 3
        ' 
        ' Overall_Rating
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Moccasin
        BackgroundImage = My.Resources.Resources.wallp
        BackgroundImageLayout = ImageLayout.Center
        ClientSize = New Size(608, 500)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.None
        MaximizeBox = False
        MaximumSize = New Size(608, 500)
        MinimumSize = New Size(608, 500)
        Name = "Overall_Rating"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Overall Rating"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents lblCourseTitle As Label
    Friend WithEvents lblOverallRating As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel2 As Panel
End Class
