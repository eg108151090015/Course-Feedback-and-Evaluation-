﻿Imports MySql.Data.MySqlClient

Public Class Overall_Rating
    Private courseID As Integer
    Private courseName As String

    Public Sub New(courseID As Integer, courseName As String)
        InitializeComponent()

        Me.courseID = courseID
        Me.courseName = courseName

        lblCourseTitle.Text = "Course: " & courseName

        DisplayOverallRating()
    End Sub

    Private Sub DisplayOverallRating()
        Try
            OpenConnection()

            Dim query As String = "SELECT AVG(overall_rating) AS overall_rating FROM course_feedback WHERE course_id = @courseID"
            Dim cmd As New MySqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@courseID", courseID)
            Dim reader As MySqlDataReader = cmd.ExecuteReader()

            If reader.HasRows Then
                reader.Read()
                lblOverallRating.Text = "Overall Rating: " & Math.Round(Convert.ToDouble(reader("overall_rating")), 2).ToString()
            Else
                lblOverallRating.Text = "No ratings available"
            End If
            reader.Close()
        Catch ex As Exception
            MessageBox.Show("Error calculating overall rating: " & ex.Message)
        Finally
            CloseConnection()
        End Try
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint
        Panel1.BackColor = Color.FromArgb(100, 0, 0, 0)
        Panel1.BorderStyle = BorderStyle.None
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Hide()
    End Sub
End Class