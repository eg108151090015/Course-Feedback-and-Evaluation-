﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Question_Form
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btnNext = New Button()
        rtbQuestion = New RichTextBox()
        rb1 = New RadioButton()
        rb2 = New RadioButton()
        rb3 = New RadioButton()
        rb4 = New RadioButton()
        rb5 = New RadioButton()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        Panel1 = New Panel()
        btnBack = New Button()
        Panel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' btnNext
        ' 
        btnNext.BackColor = Color.FromArgb(CByte(64), CByte(64), CByte(0))
        btnNext.FlatStyle = FlatStyle.Popup
        btnNext.Font = New Font("Segoe UI Black", 11.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnNext.ForeColor = Color.White
        btnNext.Location = New Point(312, 414)
        btnNext.Name = "btnNext"
        btnNext.Size = New Size(130, 33)
        btnNext.TabIndex = 63
        btnNext.Text = "Next"
        btnNext.UseVisualStyleBackColor = False
        ' 
        ' rtbQuestion
        ' 
        rtbQuestion.BorderStyle = BorderStyle.FixedSingle
        rtbQuestion.Enabled = False
        rtbQuestion.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        rtbQuestion.Location = New Point(91, 143)
        rtbQuestion.Name = "rtbQuestion"
        rtbQuestion.Size = New Size(566, 206)
        rtbQuestion.TabIndex = 67
        rtbQuestion.Text = ""
        ' 
        ' rb1
        ' 
        rb1.AutoSize = True
        rb1.Font = New Font("Segoe UI Black", 12F, FontStyle.Bold)
        rb1.ForeColor = Color.White
        rb1.Location = New Point(131, 372)
        rb1.Name = "rb1"
        rb1.Size = New Size(36, 25)
        rb1.TabIndex = 68
        rb1.TabStop = True
        rb1.Text = "1"
        rb1.UseVisualStyleBackColor = True
        ' 
        ' rb2
        ' 
        rb2.AutoSize = True
        rb2.Font = New Font("Segoe UI Black", 12F, FontStyle.Bold)
        rb2.ForeColor = Color.White
        rb2.Location = New Point(242, 372)
        rb2.Name = "rb2"
        rb2.Size = New Size(38, 25)
        rb2.TabIndex = 69
        rb2.TabStop = True
        rb2.Text = "2"
        rb2.UseVisualStyleBackColor = True
        ' 
        ' rb3
        ' 
        rb3.AutoSize = True
        rb3.Font = New Font("Segoe UI Black", 12F, FontStyle.Bold)
        rb3.ForeColor = Color.White
        rb3.Location = New Point(354, 372)
        rb3.Name = "rb3"
        rb3.Size = New Size(38, 25)
        rb3.TabIndex = 70
        rb3.TabStop = True
        rb3.Text = "3"
        rb3.UseVisualStyleBackColor = True
        ' 
        ' rb4
        ' 
        rb4.AutoSize = True
        rb4.Font = New Font("Segoe UI Black", 12F, FontStyle.Bold)
        rb4.ForeColor = Color.White
        rb4.Location = New Point(466, 372)
        rb4.Name = "rb4"
        rb4.Size = New Size(38, 25)
        rb4.TabIndex = 71
        rb4.TabStop = True
        rb4.Text = "4"
        rb4.UseVisualStyleBackColor = True
        ' 
        ' rb5
        ' 
        rb5.AutoSize = True
        rb5.Font = New Font("Segoe UI Black", 12F, FontStyle.Bold)
        rb5.ForeColor = Color.White
        rb5.Location = New Point(582, 372)
        rb5.Name = "rb5"
        rb5.Size = New Size(38, 25)
        rb5.TabIndex = 72
        rb5.TabStop = True
        rb5.Text = "5"
        rb5.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("OCR A Extended", 9.75F, FontStyle.Bold)
        Label1.ForeColor = Color.White
        Label1.Location = New Point(131, 93)
        Label1.Name = "Label1"
        Label1.Size = New Size(187, 13)
        Label1.TabIndex = 73
        Label1.Text = "1 - NONE of the time"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("OCR A Extended", 9.75F, FontStyle.Bold)
        Label2.ForeColor = Color.White
        Label2.Location = New Point(290, 93)
        Label2.Name = "Label2"
        Label2.Size = New Size(187, 13)
        Label2.TabIndex = 74
        Label2.Text = "2 - RARE of the time"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Transparent
        Label3.Font = New Font("OCR A Extended", 9.75F, FontStyle.Bold)
        Label3.ForeColor = Color.White
        Label3.Location = New Point(446, 93)
        Label3.Name = "Label3"
        Label3.Size = New Size(187, 13)
        Label3.TabIndex = 75
        Label3.Text = "3 - SOME of the time"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Transparent
        Label4.Font = New Font("OCR A Extended", 9.75F, FontStyle.Bold)
        Label4.ForeColor = Color.White
        Label4.Location = New Point(132, 112)
        Label4.Name = "Label4"
        Label4.Size = New Size(187, 13)
        Label4.TabIndex = 76
        Label4.Text = "4 - MOST of the time"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.BackColor = Color.Transparent
        Label5.Font = New Font("OCR A Extended", 9.75F, FontStyle.Bold)
        Label5.ForeColor = Color.White
        Label5.Location = New Point(290, 112)
        Label5.Name = "Label5"
        Label5.Size = New Size(178, 13)
        Label5.TabIndex = 77
        Label5.Text = "5 - ALL of the time"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.BackColor = Color.Transparent
        Label6.Font = New Font("OCR A Extended", 9.75F, FontStyle.Bold)
        Label6.ForeColor = Color.White
        Label6.Location = New Point(52, 26)
        Label6.Name = "Label6"
        Label6.Size = New Size(664, 52)
        Label6.TabIndex = 78
        Label6.Text = "INSTRUCTIONS:" & vbCrLf & "Kindly read each statement carefully and choose the number that best " & vbCrLf & "represents your response. Place your answers on the SCORE space provided." & vbCrLf & "Follow the rating scale below."
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Black
        Panel1.Controls.Add(btnBack)
        Panel1.Controls.Add(Label6)
        Panel1.Controls.Add(rtbQuestion)
        Panel1.Controls.Add(rb5)
        Panel1.Controls.Add(Label5)
        Panel1.Controls.Add(rb4)
        Panel1.Controls.Add(Label4)
        Panel1.Controls.Add(rb3)
        Panel1.Controls.Add(Label1)
        Panel1.Controls.Add(rb2)
        Panel1.Controls.Add(Label3)
        Panel1.Controls.Add(rb1)
        Panel1.Controls.Add(Label2)
        Panel1.Controls.Add(btnNext)
        Panel1.Location = New Point(-2, 2)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(745, 462)
        Panel1.TabIndex = 79
        ' 
        ' btnBack
        ' 
        btnBack.BackColor = Color.Maroon
        btnBack.FlatStyle = FlatStyle.Popup
        btnBack.Font = New Font("Segoe UI Black", 11.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnBack.ForeColor = Color.White
        btnBack.Location = New Point(14, 414)
        btnBack.Name = "btnBack"
        btnBack.Size = New Size(110, 33)
        btnBack.TabIndex = 79
        btnBack.Text = "BACK"
        btnBack.UseVisualStyleBackColor = False
        ' 
        ' Question_Form
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Moccasin
        BackgroundImage = My.Resources.Resources.wallp
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(741, 461)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.None
        MaximizeBox = False
        Name = "Question_Form"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Question Form"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        ResumeLayout(False)
    End Sub
    Friend WithEvents btnNext As Button
    Friend WithEvents rtbQuestion As RichTextBox
    Friend WithEvents rb1 As RadioButton
    Friend WithEvents rb2 As RadioButton
    Friend WithEvents rb3 As RadioButton
    Friend WithEvents rb4 As RadioButton
    Friend WithEvents rb5 As RadioButton
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnBack As Button
End Class
