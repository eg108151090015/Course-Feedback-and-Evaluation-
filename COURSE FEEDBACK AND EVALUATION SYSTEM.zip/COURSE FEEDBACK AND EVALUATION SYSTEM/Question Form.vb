﻿Imports MySql.Data.MySqlClient

Public Class Question_Form

    Dim questions As List(Of String)
    Dim currentQuestionIndex As Integer = 0

    Private courseID As Integer
    Private studentID As Integer
    Private feedbackDate As Date = Date.Now
    Private feedbackIDs As New List(Of Integer)

    Private temporaryResponses As New Dictionary(Of Integer, Integer)

    Private Sub Question_Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        questions = LoadQuestionsFromDatabase()
        DisplayCurrentQuestion()
    End Sub

    Public Sub New(courseID As Integer, studentID As Integer)
        InitializeComponent()

        Me.courseID = courseID
        Me.studentID = studentID
    End Sub

    Private Sub DisplayCurrentQuestion()
        If currentQuestionIndex >= 0 AndAlso currentQuestionIndex < questions.Count Then
            rtbQuestion.Text = questions(currentQuestionIndex)
            ClearResponses()
        End If
    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        If rb1.Checked Or rb2.Checked Or rb3.Checked Or rb4.Checked Or rb5.Checked Then
            Try
                temporaryResponses(currentQuestionIndex) = GetSelectedResponse()

                currentQuestionIndex += 1
                If currentQuestionIndex < questions.Count Then
                    DisplayCurrentQuestion()
                    If currentQuestionIndex = questions.Count - 1 Then
                        btnNext.Text = "Submit"
                    Else
                        btnNext.Text = "Next"
                    End If
                Else
                    CommitResponses()
                    CalculateAndStoreOverallRating()
                    MessageBox.Show("You have completed the evaluation.")

                    btnNext.Enabled = False

                    rb1.Enabled = False
                    rb2.Enabled = False
                    rb3.Enabled = False
                    rb4.Enabled = False
                    rb5.Enabled = False
                End If
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message & vbCrLf & "Stack Trace: " & ex.StackTrace)
            End Try
        Else
            MessageBox.Show("Please select a rating.")
        End If
    End Sub

    Private Function GetSelectedResponse() As Integer
        If rb1.Checked Then Return 1
        If rb2.Checked Then Return 2
        If rb3.Checked Then Return 3
        If rb4.Checked Then Return 4
        If rb5.Checked Then Return 5
        Return 0
    End Function

    Private Sub ClearResponses()
        rb1.Checked = False
        rb2.Checked = False
        rb3.Checked = False
        rb4.Checked = False
        rb5.Checked = False
    End Sub

    Private Sub CommitResponses()
        Try
            OpenConnection()
            For Each kvp As KeyValuePair(Of Integer, Integer) In temporaryResponses
                Dim query As String = "INSERT INTO feedback_responses (feedback_id, course_id, question_id, response) VALUES (NULL, @courseID, @questionID, @response)"
                Dim cmd As New MySqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@courseID", courseID)
                cmd.Parameters.AddWithValue("@questionID", kvp.Key + 1)
                cmd.Parameters.AddWithValue("@response", kvp.Value)
                cmd.ExecuteNonQuery()

                Dim feedbackIdQuery As String = "SELECT LAST_INSERT_ID()"
                Dim feedbackIdCmd As New MySqlCommand(feedbackIdQuery, conn)
                Dim feedbackID As Integer = Convert.ToInt32(feedbackIdCmd.ExecuteScalar())

                feedbackIDs.Add(feedbackID)
            Next
        Catch ex As Exception
            MessageBox.Show("Error committing responses: " & ex.Message & vbCrLf & "Stack Trace: " & ex.StackTrace)
        Finally
            CloseConnection()
        End Try
    End Sub

    Private Function LoadQuestionsFromDatabase() As List(Of String)
        Dim questionList As New List(Of String)

        Try
            OpenConnection()

            Dim query As String = "SELECT question_text FROM feedback_questions"
            Dim cmd As New MySqlCommand(query, conn)
            Dim reader As MySqlDataReader = cmd.ExecuteReader()

            While reader.Read()
                questionList.Add(reader("question_text").ToString())
            End While

            reader.Close()
        Catch ex As Exception
            MessageBox.Show("Error loading questions: " & ex.Message)
        Finally
            CloseConnection()
        End Try

        Return questionList
    End Function

    Private Sub CalculateAndStoreOverallRating()
        Try
            OpenConnection()

            Dim query As String = "SELECT AVG(response) AS overall_rating FROM feedback_responses WHERE course_id = @courseID"
            Dim cmd As New MySqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@courseID", courseID)
            Dim reader As MySqlDataReader = cmd.ExecuteReader()

            Dim overallRating As Double = 0
            If reader.HasRows Then
                reader.Read()
                overallRating = Convert.ToDouble(reader("overall_rating"))
            End If
            reader.Close()

            Dim insertQuery As String = "INSERT INTO course_feedback (feedback_id, student_id, course_id, feedback_date, overall_rating) VALUES (@feedbackID, @studentID, @courseID, @feedbackDate, @overallRating)"
            For Each feedbackID As Integer In feedbackIDs
                Dim insertCmd As New MySqlCommand(insertQuery, conn)
                insertCmd.Parameters.AddWithValue("@feedbackID", feedbackID)
                insertCmd.Parameters.AddWithValue("@studentID", studentID)
                insertCmd.Parameters.AddWithValue("@courseID", courseID)
                insertCmd.Parameters.AddWithValue("@feedbackDate", DateTime.Now)
                insertCmd.Parameters.AddWithValue("@overallRating", overallRating)
                insertCmd.ExecuteNonQuery()
            Next

        Catch ex As Exception
            MessageBox.Show("Error storing overall rating: " & ex.Message & vbCrLf & "Stack Trace: " & ex.StackTrace)
        Finally
            CloseConnection()
        End Try
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint
        Panel1.BackColor = Color.FromArgb(100, 0, 0, 0)
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        temporaryResponses.Clear()
        Me.Hide()
    End Sub
End Class