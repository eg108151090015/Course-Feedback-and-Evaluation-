﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Student_Form_Courses
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Student_Form_Courses))
        HelloADMIN = New ToolStripMenuItem()
        DASHBOARD = New ToolStripMenuItem()
        PROFILE = New ToolStripMenuItem()
        COURSES = New ToolStripMenuItem()
        adminMenu = New MenuStrip()
        lvCourses = New ListView()
        btnClear = New Button()
        Label1 = New Label()
        btnStart = New Button()
        adminMenu.SuspendLayout()
        SuspendLayout()
        ' 
        ' HelloADMIN
        ' 
        HelloADMIN.BackColor = Color.Transparent
        HelloADMIN.Font = New Font("OCR A Extended", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        HelloADMIN.ForeColor = Color.White
        HelloADMIN.ImageAlign = ContentAlignment.MiddleLeft
        HelloADMIN.Name = "HelloADMIN"
        HelloADMIN.Size = New Size(141, 27)
        HelloADMIN.Text = "Hello, #!"
        ' 
        ' DASHBOARD
        ' 
        DASHBOARD.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        DASHBOARD.ForeColor = Color.White
        DASHBOARD.Image = CType(resources.GetObject("DASHBOARD.Image"), Image)
        DASHBOARD.ImageAlign = ContentAlignment.MiddleLeft
        DASHBOARD.Name = "DASHBOARD"
        DASHBOARD.Size = New Size(141, 24)
        DASHBOARD.Text = "DASHBOARD"
        DASHBOARD.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' PROFILE
        ' 
        PROFILE.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        PROFILE.ForeColor = Color.White
        PROFILE.Image = CType(resources.GetObject("PROFILE.Image"), Image)
        PROFILE.ImageAlign = ContentAlignment.MiddleLeft
        PROFILE.Name = "PROFILE"
        PROFILE.Size = New Size(141, 24)
        PROFILE.Text = "PROFILE"
        PROFILE.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' COURSES
        ' 
        COURSES.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        COURSES.ForeColor = Color.White
        COURSES.Image = CType(resources.GetObject("COURSES.Image"), Image)
        COURSES.ImageAlign = ContentAlignment.MiddleLeft
        COURSES.Name = "COURSES"
        COURSES.Size = New Size(141, 24)
        COURSES.Text = "COURSES"
        COURSES.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' adminMenu
        ' 
        adminMenu.BackColor = Color.FromArgb(CByte(64), CByte(0), CByte(0))
        adminMenu.Dock = DockStyle.Left
        adminMenu.Font = New Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        adminMenu.Items.AddRange(New ToolStripItem() {HelloADMIN, DASHBOARD, PROFILE, COURSES})
        adminMenu.Location = New Point(0, 0)
        adminMenu.Name = "adminMenu"
        adminMenu.Size = New Size(154, 500)
        adminMenu.TabIndex = 33
        adminMenu.Text = "Admin Menu"
        ' 
        ' lvCourses
        ' 
        lvCourses.FullRowSelect = True
        lvCourses.GridLines = True
        lvCourses.Location = New Point(306, 31)
        lvCourses.Name = "lvCourses"
        lvCourses.Size = New Size(566, 381)
        lvCourses.TabIndex = 56
        lvCourses.UseCompatibleStateImageBehavior = False
        lvCourses.View = View.Details
        ' 
        ' btnClear
        ' 
        btnClear.BackColor = Color.Maroon
        btnClear.FlatStyle = FlatStyle.Popup
        btnClear.Font = New Font("Segoe UI Black", 11.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnClear.ForeColor = Color.White
        btnClear.Location = New Point(742, 418)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(130, 33)
        btnClear.TabIndex = 55
        btnClear.Text = "CLEAR"
        btnClear.UseVisualStyleBackColor = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("OCR A Extended", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.White
        Label1.Location = New Point(306, 9)
        Label1.Name = "Label1"
        Label1.Size = New Size(177, 20)
        Label1.TabIndex = 52
        Label1.Text = "Select Course:"
        ' 
        ' btnStart
        ' 
        btnStart.BackColor = Color.FromArgb(CByte(64), CByte(64), CByte(0))
        btnStart.FlatStyle = FlatStyle.Popup
        btnStart.Font = New Font("Segoe UI Black", 11.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnStart.ForeColor = Color.White
        btnStart.Location = New Point(306, 418)
        btnStart.Name = "btnStart"
        btnStart.Size = New Size(130, 33)
        btnStart.TabIndex = 58
        btnStart.Text = "START"
        btnStart.UseVisualStyleBackColor = False
        ' 
        ' Student_Form_Courses
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Moccasin
        BackgroundImage = My.Resources.Resources.wallp
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(900, 500)
        Controls.Add(btnStart)
        Controls.Add(lvCourses)
        Controls.Add(btnClear)
        Controls.Add(Label1)
        Controls.Add(adminMenu)
        FormBorderStyle = FormBorderStyle.None
        MaximizeBox = False
        MaximumSize = New Size(900, 500)
        MinimumSize = New Size(900, 500)
        Name = "Student_Form_Courses"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Student Form Courses"
        adminMenu.ResumeLayout(False)
        adminMenu.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents HelloADMIN As ToolStripMenuItem
    Friend WithEvents DASHBOARD As ToolStripMenuItem
    Friend WithEvents PROFILE As ToolStripMenuItem
    Friend WithEvents COURSES As ToolStripMenuItem
    Friend WithEvents adminMenu As MenuStrip
    Friend WithEvents lvCourses As ListView
    Friend WithEvents btnClear As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents btnStart As Button
End Class
