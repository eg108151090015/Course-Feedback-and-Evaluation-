﻿Imports MySql.Data.MySqlClient

Public Class Student_Form_Courses
    Public Property FirstName As String

    Public LoggedInStudentID As String

    Private answeredCourses As New Dictionary(Of String, Boolean)

    Private Sub Student_Form_Courses_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lvCourses.View = View.Details
        lvCourses.Columns.Clear()
        lvCourses.Columns.Add("Course Name", 150, HorizontalAlignment.Left)
        lvCourses.Columns.Add("Course Code", 100, HorizontalAlignment.Left)
        lvCourses.Columns.Add("Instructor", 150, HorizontalAlignment.Left)

        If Not String.IsNullOrEmpty(FirstName) Then
            adminMenu.Items(0).Text = "Hello, " & FirstName
        Else
            adminMenu.Items(0).Text = "Hello, Student!"
        End If

        DisplayStudentCourses(LoggedInStudentID)
    End Sub

    Private Sub DASHBOARD_Click(sender As Object, e As EventArgs) Handles DASHBOARD.Click
        Dim anotherForm As New Student_Form()
        anotherForm.FirstName = Me.FirstName
        anotherForm.LoggedInStudentID = Me.LoggedInStudentID
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub PROFILE_Click(sender As Object, e As EventArgs) Handles PROFILE.Click
        Dim anotherForm As New Student_Form_Profile()
        anotherForm.FirstName = Me.FirstName
        anotherForm.LoggedInStudentID = Me.LoggedInStudentID
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub DisplayStudentCourses(studentID As String)
        Try
            OpenConnection()

            Dim query As String = "SELECT c.course_id, c.course_code, c.course_name, " &
                              "CONCAT(i.first_name, ' ', i.last_name) AS instructor_name " &
                              "FROM courses c " &
                              "JOIN student_courses sc ON c.course_id = sc.course_id " &
                              "JOIN instructors i ON c.instructor_id = i.instructor_id " &
                              "WHERE sc.student_id = @studentID"
            Dim cmd As New MySqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@studentID", studentID)

            Dim reader As MySqlDataReader = cmd.ExecuteReader()

            lvCourses.Items.Clear()
            If reader.HasRows Then
                While reader.Read()
                    Dim item As New ListViewItem(reader("course_name").ToString())
                    item.SubItems.Add(reader("course_code").ToString())
                    item.SubItems.Add(reader("instructor_name").ToString()) '
                    item.Tag = reader("course_id")
                    lvCourses.Items.Add(item)
                End While
            Else
                MessageBox.Show("No courses found for this student.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

            reader.Close()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CloseConnection()
        End Try
    End Sub

    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        If lvCourses.SelectedItems.Count <= 0 Then
            MessageBox.Show("Please select a course first.")
            Return
        End If

        Dim selectedCourse As String = lvCourses.SelectedItems(0).Text
        Dim selectedCourseID As Integer = Convert.ToInt32(lvCourses.SelectedItems(0).Tag)
        Dim studentID As Integer = GetLoggedInStudentID()

        If Not IsCourseIDValid(selectedCourseID) Then
            MessageBox.Show("Invalid course selected. Please select a valid course.")
            Return
        End If

        If IsCourseAlreadyAnswered(studentID, selectedCourseID) Then
            MessageBox.Show("You have already responded to this course.")
        Else
            Dim evaluationForm As New Question_Form(selectedCourseID, studentID)
            evaluationForm.Show()

            answeredCourses(selectedCourse) = True
        End If
    End Sub

    Private Function IsCourseAlreadyAnswered(studentID As Integer, courseID As Integer) As Boolean
        Try
            OpenConnection()
            Dim query As String = "SELECT COUNT(*) FROM course_feedback WHERE student_id = @studentID AND course_id = @courseID"
            Dim cmd As New MySqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@studentID", studentID)
            cmd.Parameters.AddWithValue("@courseID", courseID)
            Dim count As Integer = Convert.ToInt32(cmd.ExecuteScalar())
            Return count > 0
        Catch ex As Exception
            MessageBox.Show("Error checking if course is already answered: " & ex.Message)
            Return False
        Finally
            CloseConnection()
        End Try
    End Function

    Private Function GetLoggedInStudentID() As Integer
        Return LoggedInStudentID
    End Function

    Private Function IsCourseIDValid(courseID As Integer) As Boolean
        Try
            OpenConnection()
            Dim query As String = "SELECT COUNT(*) FROM courses WHERE course_id = @courseID"
            Dim cmd As New MySqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@courseID", courseID)
            Dim result As Integer = Convert.ToInt32(cmd.ExecuteScalar())
            Return result > 0
        Catch ex As Exception
            MessageBox.Show("Error checking course ID: " & ex.Message)
            Return False
        Finally
            CloseConnection()
        End Try
    End Function

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lvCourses.SelectedItems.Clear()
        btnStart.Enabled = False
    End Sub

    Private Sub lvCourses_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvCourses.SelectedIndexChanged
        btnStart.Enabled = True
    End Sub
End Class