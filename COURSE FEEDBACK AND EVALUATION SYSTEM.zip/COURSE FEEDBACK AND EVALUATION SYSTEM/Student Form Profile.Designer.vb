﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Student_Form_Profile
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Student_Form_Profile))
        HelloADMIN = New ToolStripMenuItem()
        DASHBOARD = New ToolStripMenuItem()
        PROFILE = New ToolStripMenuItem()
        COURSES = New ToolStripMenuItem()
        adminMenu = New MenuStrip()
        PictureBox1 = New PictureBox()
        Label1 = New Label()
        lblStudentID = New Label()
        lblFirstName = New Label()
        Label3 = New Label()
        lblLastName = New Label()
        Label4 = New Label()
        lblEmail = New Label()
        Label5 = New Label()
        Panel1 = New Panel()
        adminMenu.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        Panel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' HelloADMIN
        ' 
        HelloADMIN.BackColor = Color.Transparent
        HelloADMIN.Font = New Font("OCR A Extended", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        HelloADMIN.ForeColor = Color.White
        HelloADMIN.ImageAlign = ContentAlignment.MiddleLeft
        HelloADMIN.Name = "HelloADMIN"
        HelloADMIN.Size = New Size(141, 27)
        HelloADMIN.Text = "Hello, #!"
        ' 
        ' DASHBOARD
        ' 
        DASHBOARD.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        DASHBOARD.ForeColor = Color.White
        DASHBOARD.Image = CType(resources.GetObject("DASHBOARD.Image"), Image)
        DASHBOARD.ImageAlign = ContentAlignment.MiddleLeft
        DASHBOARD.Name = "DASHBOARD"
        DASHBOARD.Size = New Size(141, 24)
        DASHBOARD.Text = "DASHBOARD"
        DASHBOARD.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' PROFILE
        ' 
        PROFILE.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        PROFILE.ForeColor = Color.White
        PROFILE.Image = CType(resources.GetObject("PROFILE.Image"), Image)
        PROFILE.ImageAlign = ContentAlignment.MiddleLeft
        PROFILE.Name = "PROFILE"
        PROFILE.Size = New Size(141, 24)
        PROFILE.Text = "PROFILE"
        PROFILE.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' COURSES
        ' 
        COURSES.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        COURSES.ForeColor = Color.White
        COURSES.Image = CType(resources.GetObject("COURSES.Image"), Image)
        COURSES.ImageAlign = ContentAlignment.MiddleLeft
        COURSES.Name = "COURSES"
        COURSES.Size = New Size(141, 24)
        COURSES.Text = "COURSES"
        COURSES.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' adminMenu
        ' 
        adminMenu.BackColor = Color.FromArgb(CByte(64), CByte(0), CByte(0))
        adminMenu.Dock = DockStyle.Left
        adminMenu.Font = New Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        adminMenu.Items.AddRange(New ToolStripItem() {HelloADMIN, DASHBOARD, PROFILE, COURSES})
        adminMenu.Location = New Point(0, 0)
        adminMenu.Name = "adminMenu"
        adminMenu.Size = New Size(154, 500)
        adminMenu.TabIndex = 9
        adminMenu.Text = "Admin Menu"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.Image = My.Resources.Resources._935bd762733715_5a999400642f7
        PictureBox1.Location = New Point(218, 13)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(100, 85)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 10
        PictureBox1.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("Segoe UI Black", 14.25F, FontStyle.Bold)
        Label1.ForeColor = Color.White
        Label1.Location = New Point(56, 143)
        Label1.Name = "Label1"
        Label1.Size = New Size(118, 25)
        Label1.TabIndex = 25
        Label1.Text = "Student ID:"
        ' 
        ' lblStudentID
        ' 
        lblStudentID.AutoSize = True
        lblStudentID.BackColor = Color.Transparent
        lblStudentID.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        lblStudentID.ForeColor = Color.White
        lblStudentID.Location = New Point(180, 143)
        lblStudentID.Name = "lblStudentID"
        lblStudentID.Size = New Size(51, 21)
        lblStudentID.TabIndex = 26
        lblStudentID.Text = "Label"
        ' 
        ' lblFirstName
        ' 
        lblFirstName.AutoSize = True
        lblFirstName.BackColor = Color.Transparent
        lblFirstName.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        lblFirstName.ForeColor = Color.White
        lblFirstName.Location = New Point(180, 207)
        lblFirstName.Name = "lblFirstName"
        lblFirstName.Size = New Size(51, 21)
        lblFirstName.TabIndex = 28
        lblFirstName.Text = "Label"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Transparent
        Label3.Font = New Font("Segoe UI Black", 14.25F, FontStyle.Bold)
        Label3.ForeColor = Color.White
        Label3.Location = New Point(56, 204)
        Label3.Name = "Label3"
        Label3.Size = New Size(119, 25)
        Label3.TabIndex = 27
        Label3.Text = "First Name:"
        ' 
        ' lblLastName
        ' 
        lblLastName.AutoSize = True
        lblLastName.BackColor = Color.Transparent
        lblLastName.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        lblLastName.ForeColor = Color.White
        lblLastName.Location = New Point(178, 269)
        lblLastName.Name = "lblLastName"
        lblLastName.Size = New Size(51, 21)
        lblLastName.TabIndex = 30
        lblLastName.Text = "Label"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Transparent
        Label4.Font = New Font("Segoe UI Black", 14.25F, FontStyle.Bold)
        Label4.ForeColor = Color.White
        Label4.Location = New Point(56, 266)
        Label4.Name = "Label4"
        Label4.Size = New Size(116, 25)
        Label4.TabIndex = 29
        Label4.Text = "Last Name:"
        ' 
        ' lblEmail
        ' 
        lblEmail.AutoSize = True
        lblEmail.BackColor = Color.Transparent
        lblEmail.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        lblEmail.ForeColor = Color.White
        lblEmail.Location = New Point(131, 330)
        lblEmail.Name = "lblEmail"
        lblEmail.Size = New Size(51, 21)
        lblEmail.TabIndex = 32
        lblEmail.Text = "Label"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.BackColor = Color.Transparent
        Label5.Font = New Font("Segoe UI Black", 14.25F, FontStyle.Bold)
        Label5.ForeColor = Color.White
        Label5.Location = New Point(56, 327)
        Label5.Name = "Label5"
        Label5.Size = New Size(69, 25)
        Label5.TabIndex = 31
        Label5.Text = "Email:"
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Black
        Panel1.Controls.Add(PictureBox1)
        Panel1.Controls.Add(lblEmail)
        Panel1.Controls.Add(Label1)
        Panel1.Controls.Add(Label5)
        Panel1.Controls.Add(lblStudentID)
        Panel1.Controls.Add(lblLastName)
        Panel1.Controls.Add(Label3)
        Panel1.Controls.Add(Label4)
        Panel1.Controls.Add(lblFirstName)
        Panel1.Location = New Point(300, 52)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(519, 406)
        Panel1.TabIndex = 33
        ' 
        ' Student_Form_Profile
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Moccasin
        BackgroundImage = My.Resources.Resources.wallp
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(900, 500)
        Controls.Add(Panel1)
        Controls.Add(adminMenu)
        DoubleBuffered = True
        FormBorderStyle = FormBorderStyle.None
        MaximizeBox = False
        MaximumSize = New Size(900, 500)
        MinimumSize = New Size(900, 500)
        Name = "Student_Form_Profile"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Student Form Profile"
        adminMenu.ResumeLayout(False)
        adminMenu.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents HelloADMIN As ToolStripMenuItem
    Friend WithEvents DASHBOARD As ToolStripMenuItem
    Friend WithEvents PROFILE As ToolStripMenuItem
    Friend WithEvents COURSES As ToolStripMenuItem
    Friend WithEvents adminMenu As MenuStrip
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents lblStudentID As Label
    Friend WithEvents lblFirstName As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblLastName As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblEmail As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Panel1 As Panel
End Class
