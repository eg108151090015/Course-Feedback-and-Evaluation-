﻿Imports MySql.Data.MySqlClient

Public Class Student_Form_Profile
    Public Property FirstName As String

    Public LoggedInStudentID As String

    Private Sub Student_Form_Profile_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Not String.IsNullOrEmpty(FirstName) Then
            adminMenu.Items(0).Text = "Hello, " & FirstName
        Else
            adminMenu.Items(0).Text = "Hello, Student!"
        End If

        Try
            OpenConnection()

            Dim query As String = "SELECT * FROM students WHERE student_id = @studentID"
            Dim cmd As New MySqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@studentID", LoggedInStudentID)

            Dim reader As MySqlDataReader = cmd.ExecuteReader()

            If reader.HasRows Then
                reader.Read()
                lblStudentID.Text = reader("student_id").ToString()
                lblFirstName.Text = reader("first_name").ToString()
                lblLastName.Text = reader("last_name").ToString()
                lblEmail.Text = reader("email").ToString()
                reader.Close()
            Else
                MessageBox.Show("Student data not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                reader.Close()
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CloseConnection()
        End Try
    End Sub

    Private Sub DASHBOARD_Click(sender As Object, e As EventArgs) Handles DASHBOARD.Click
        Dim anotherForm As New Student_Form()
        anotherForm.FirstName = Me.FirstName
        anotherForm.LoggedInStudentID = Me.LoggedInStudentID
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub COURSES_Click(sender As Object, e As EventArgs) Handles COURSES.Click
        Dim anotherForm As New Student_Form_Courses()
        anotherForm.FirstName = Me.FirstName
        anotherForm.LoggedInStudentID = Me.LoggedInStudentID
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint
        Panel1.BackColor = Color.FromArgb(100, 0, 0, 0)
    End Sub
End Class