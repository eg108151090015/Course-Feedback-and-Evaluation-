﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Student_Form
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Student_Form))
        PictureBox2 = New PictureBox()
        Label2 = New Label()
        pMyCourses = New Panel()
        Label1 = New Label()
        pMyProfile = New Panel()
        COURSES = New ToolStripMenuItem()
        PROFILE = New ToolStripMenuItem()
        DASHBOARD = New ToolStripMenuItem()
        HelloADMIN = New ToolStripMenuItem()
        adminMenu = New MenuStrip()
        btnLogout = New Button()
        PictureBox1 = New PictureBox()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        pMyCourses.SuspendLayout()
        pMyProfile.SuspendLayout()
        adminMenu.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackColor = Color.Transparent
        PictureBox2.BackgroundImage = My.Resources.Resources.book
        PictureBox2.Image = My.Resources.Resources.book
        PictureBox2.Location = New Point(96, 3)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(103, 96)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 2
        PictureBox2.TabStop = False
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("OCR A Extended", 12F, FontStyle.Bold)
        Label2.ForeColor = Color.White
        Label2.Location = New Point(5, 16)
        Label2.Name = "Label2"
        Label2.Size = New Size(85, 17)
        Label2.TabIndex = 1
        Label2.Text = "COURSES"
        ' 
        ' pMyCourses
        ' 
        pMyCourses.BackColor = Color.FromArgb(CByte(64), CByte(0), CByte(0))
        pMyCourses.BorderStyle = BorderStyle.FixedSingle
        pMyCourses.Controls.Add(PictureBox2)
        pMyCourses.Controls.Add(Label2)
        pMyCourses.Location = New Point(565, 162)
        pMyCourses.Name = "pMyCourses"
        pMyCourses.Size = New Size(200, 100)
        pMyCourses.TabIndex = 8
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("OCR A Extended", 12F, FontStyle.Bold)
        Label1.ForeColor = Color.White
        Label1.Location = New Point(5, 16)
        Label1.Name = "Label1"
        Label1.Size = New Size(85, 17)
        Label1.TabIndex = 1
        Label1.Text = "PROFILE"
        ' 
        ' pMyProfile
        ' 
        pMyProfile.BackColor = Color.FromArgb(CByte(64), CByte(0), CByte(0))
        pMyProfile.BorderStyle = BorderStyle.FixedSingle
        pMyProfile.Controls.Add(PictureBox1)
        pMyProfile.Controls.Add(Label1)
        pMyProfile.Location = New Point(340, 162)
        pMyProfile.Name = "pMyProfile"
        pMyProfile.Size = New Size(200, 100)
        pMyProfile.TabIndex = 7
        ' 
        ' COURSES
        ' 
        COURSES.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        COURSES.ForeColor = Color.White
        COURSES.Image = CType(resources.GetObject("COURSES.Image"), Image)
        COURSES.ImageAlign = ContentAlignment.MiddleLeft
        COURSES.Name = "COURSES"
        COURSES.Size = New Size(141, 24)
        COURSES.Text = "COURSES"
        COURSES.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' PROFILE
        ' 
        PROFILE.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        PROFILE.ForeColor = Color.White
        PROFILE.Image = CType(resources.GetObject("PROFILE.Image"), Image)
        PROFILE.ImageAlign = ContentAlignment.MiddleLeft
        PROFILE.Name = "PROFILE"
        PROFILE.Size = New Size(141, 24)
        PROFILE.Text = "PROFILE"
        PROFILE.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' DASHBOARD
        ' 
        DASHBOARD.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        DASHBOARD.ForeColor = Color.White
        DASHBOARD.Image = CType(resources.GetObject("DASHBOARD.Image"), Image)
        DASHBOARD.ImageAlign = ContentAlignment.MiddleLeft
        DASHBOARD.Name = "DASHBOARD"
        DASHBOARD.Size = New Size(141, 24)
        DASHBOARD.Text = "DASHBOARD"
        DASHBOARD.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' HelloADMIN
        ' 
        HelloADMIN.BackColor = Color.Transparent
        HelloADMIN.Font = New Font("OCR A Extended", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        HelloADMIN.ForeColor = Color.White
        HelloADMIN.ImageAlign = ContentAlignment.MiddleLeft
        HelloADMIN.Name = "HelloADMIN"
        HelloADMIN.Size = New Size(141, 27)
        HelloADMIN.Text = "Hello, #!"
        ' 
        ' adminMenu
        ' 
        adminMenu.BackColor = Color.FromArgb(CByte(64), CByte(0), CByte(0))
        adminMenu.Dock = DockStyle.Left
        adminMenu.Font = New Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        adminMenu.Items.AddRange(New ToolStripItem() {HelloADMIN, DASHBOARD, PROFILE, COURSES})
        adminMenu.Location = New Point(0, 0)
        adminMenu.Name = "adminMenu"
        adminMenu.Size = New Size(154, 500)
        adminMenu.TabIndex = 6
        adminMenu.Text = "Admin Menu"
        ' 
        ' btnLogout
        ' 
        btnLogout.BackColor = Color.Maroon
        btnLogout.FlatStyle = FlatStyle.Popup
        btnLogout.Font = New Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnLogout.ForeColor = Color.White
        btnLogout.Location = New Point(749, 455)
        btnLogout.Name = "btnLogout"
        btnLogout.Size = New Size(130, 33)
        btnLogout.TabIndex = 22
        btnLogout.Text = "LOGOUT"
        btnLogout.UseVisualStyleBackColor = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.R1
        PictureBox1.Location = New Point(96, 16)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(99, 68)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 2
        PictureBox1.TabStop = False
        ' 
        ' Student_Form
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Moccasin
        BackgroundImage = My.Resources.Resources.wallp
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(900, 500)
        Controls.Add(btnLogout)
        Controls.Add(pMyCourses)
        Controls.Add(pMyProfile)
        Controls.Add(adminMenu)
        FormBorderStyle = FormBorderStyle.None
        MaximizeBox = False
        MaximumSize = New Size(900, 500)
        MinimumSize = New Size(900, 500)
        Name = "Student_Form"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Student Form"
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        pMyCourses.ResumeLayout(False)
        pMyCourses.PerformLayout()
        pMyProfile.ResumeLayout(False)
        pMyProfile.PerformLayout()
        adminMenu.ResumeLayout(False)
        adminMenu.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents lblTotalFeedback As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents lblTotalStudents As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents pMyCourses As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents pMyProfile As Panel
    Friend WithEvents REPORT As ToolStripMenuItem
    Friend WithEvents COURSES As ToolStripMenuItem
    Friend WithEvents PROFILE As ToolStripMenuItem
    Friend WithEvents DASHBOARD As ToolStripMenuItem
    Friend WithEvents HelloADMIN As ToolStripMenuItem
    Friend WithEvents adminMenu As MenuStrip
    Friend WithEvents btnLogout As Button
    Friend WithEvents PictureBox1 As PictureBox
End Class
