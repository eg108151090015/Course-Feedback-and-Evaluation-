﻿Public Class Student_Form

    Public Property FirstName As String

    Public LoggedInStudentID As String
    Private Sub Student_Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Not String.IsNullOrEmpty(FirstName) Then
            adminMenu.Items(0).Text = "Hello, " & FirstName
        Else
            adminMenu.Items(0).Text = "Hello, Student!"
        End If
    End Sub

    Private Sub PROFILE_Click(sender As Object, e As EventArgs) Handles PROFILE.Click
        Dim anotherForm As New Student_Form_Profile()
        anotherForm.FirstName = Me.FirstName
        anotherForm.LoggedInStudentID = Me.LoggedInStudentID
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub pMyProfile_Click(sender As Object, e As EventArgs) Handles pMyProfile.Click
        Dim anotherForm As New Student_Form_Profile()
        anotherForm.FirstName = Me.FirstName
        anotherForm.LoggedInStudentID = Me.LoggedInStudentID
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub COURSES_Click(sender As Object, e As EventArgs) Handles COURSES.Click
        Dim anotherForm As New Student_Form_Courses()
        anotherForm.FirstName = Me.FirstName
        anotherForm.LoggedInStudentID = Me.LoggedInStudentID
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub pMyCourses_Click(sender As Object, e As EventArgs) Handles pMyCourses.Click
        Dim anotherForm As New Student_Form_Courses()
        anotherForm.FirstName = Me.FirstName
        anotherForm.LoggedInStudentID = Me.LoggedInStudentID
        anotherForm.Show()
        Me.Hide()
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        OpenConnection()
        LoginForm.txtUserName.Text = ""
        LoginForm.txtPassword.Text = ""
        LoginForm.cbShowHidePassword.Checked = False

        LoginForm.Show()
        Me.Hide()
    End Sub
End Class