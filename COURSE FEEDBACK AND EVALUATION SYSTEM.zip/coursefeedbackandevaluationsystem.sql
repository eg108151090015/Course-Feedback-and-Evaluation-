-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2024 at 10:37 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coursefeedbackandevaluationsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `userID` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`userID`, `username`, `password`, `role`) VALUES
(1, 'admin', 'password', 'admin'),
(3, '2022010715', 'password', 'student');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(100) DEFAULT NULL,
  `course_code` varchar(20) DEFAULT NULL,
  `instructor_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course_name`, `course_code`, `instructor_id`) VALUES
(1, 'Advanced Database Systems', 'ITEC48', 1),
(2, 'Networking 2', 'ITEC51', 2),
(3, 'System Integration & Architecture 1', 'ITEC54', 3),
(4, 'Social Issues and Professional Issues', 'ITEC60', 4),
(5, 'Enterprise Data Management', 'ITEC79', 4),
(6, 'Event Driven Programming', 'ITEC81', 5),
(7, 'Multimedia Systems', 'ITEC93', 6);

-- --------------------------------------------------------

--
-- Table structure for table `course_feedback`
--

CREATE TABLE `course_feedback` (
  `feedback_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `feedback_date` date DEFAULT NULL,
  `overall_rating` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course_feedback`
--

INSERT INTO `course_feedback` (`feedback_id`, `student_id`, `course_id`, `feedback_date`, `overall_rating`) VALUES
(42, 2022010715, 1, '2024-12-15', 5),
(43, 2022010715, 1, '2024-12-15', 5),
(44, 2022010715, 1, '2024-12-15', 5),
(45, 2022010715, 1, '2024-12-15', 5),
(46, 2022010715, 1, '2024-12-15', 5),
(47, 2022010715, 1, '2024-12-15', 5),
(48, 2022010715, 1, '2024-12-15', 5),
(49, 2022010715, 1, '2024-12-15', 5),
(50, 2022010715, 1, '2024-12-15', 5),
(51, 2022010715, 1, '2024-12-15', 5),
(52, 2022010715, 2, '2024-12-15', 3.3),
(53, 2022010715, 2, '2024-12-15', 3.3),
(54, 2022010715, 2, '2024-12-15', 3.3),
(55, 2022010715, 2, '2024-12-15', 3.3),
(56, 2022010715, 2, '2024-12-15', 3.3),
(57, 2022010715, 2, '2024-12-15', 3.3),
(58, 2022010715, 2, '2024-12-15', 3.3),
(59, 2022010715, 2, '2024-12-15', 3.3),
(60, 2022010715, 2, '2024-12-15', 3.3),
(61, 2022010715, 2, '2024-12-15', 3.3),
(62, 2022010715, 3, '2024-12-15', 3.8),
(63, 2022010715, 3, '2024-12-15', 3.8),
(64, 2022010715, 3, '2024-12-15', 3.8),
(65, 2022010715, 3, '2024-12-15', 3.8),
(66, 2022010715, 3, '2024-12-15', 3.8),
(67, 2022010715, 3, '2024-12-15', 3.8),
(68, 2022010715, 3, '2024-12-15', 3.8),
(69, 2022010715, 3, '2024-12-15', 3.8),
(70, 2022010715, 3, '2024-12-15', 3.8),
(71, 2022010715, 3, '2024-12-15', 3.8);

-- --------------------------------------------------------

--
-- Table structure for table `feedback_questions`
--

CREATE TABLE `feedback_questions` (
  `question_id` int(11) NOT NULL,
  `question_text` varchar(255) DEFAULT NULL,
  `question_type` varchar(50) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback_questions`
--

INSERT INTO `feedback_questions` (`question_id`, `question_text`, `question_type`, `category`) VALUES
(1, 'The instructor demonstrates mastery of the subject content.', 'rating', 'course content'),
(2, 'The instructor presents the lessons clearly and understandably.', 'rating', 'course content'),
(3, 'The instructor relates the lessons to real-life situations. ', 'rating', 'course content'),
(4, 'The instructor encourages the students’ active participation and interaction in the learning process.', 'rating', 'course content'),
(5, 'The instructor creates specific, concrete examples to clarify abstract ideas.', 'rating', 'course content'),
(6, 'The instructor utilizes updated references and illustrations in the class.', 'rating', 'course content'),
(7, 'The instructor provides opportunities for the students to ask questions.', 'rating', 'course content'),
(8, 'The instructor uses motivational strategies in delivering the subject matter.', 'rating', 'course content'),
(9, 'The instructor employs varied instructional materials and technology to enhance lecture.', 'rating', 'course content'),
(10, 'The instructor gives prompt and meaningful feedback on your outputs.', 'rating', 'course content');

-- --------------------------------------------------------

--
-- Table structure for table `feedback_responses`
--

CREATE TABLE `feedback_responses` (
  `feedback_id` int(11) NOT NULL,
  `question_id` int(11) DEFAULT NULL,
  `response` text DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback_responses`
--

INSERT INTO `feedback_responses` (`feedback_id`, `question_id`, `response`, `course_id`) VALUES
(42, 1, '5', 1),
(43, 2, '5', 1),
(44, 3, '5', 1),
(45, 4, '5', 1),
(46, 5, '5', 1),
(47, 6, '5', 1),
(48, 7, '5', 1),
(49, 8, '5', 1),
(50, 9, '5', 1),
(51, 10, '5', 1),
(52, 1, '4', 2),
(53, 2, '3', 2),
(54, 3, '5', 2),
(55, 4, '2', 2),
(56, 5, '3', 2),
(57, 6, '4', 2),
(58, 7, '3', 2),
(59, 8, '1', 2),
(60, 9, '5', 2),
(61, 10, '3', 2),
(62, 1, '3', 3),
(63, 2, '4', 3),
(64, 3, '2', 3),
(65, 4, '5', 3),
(66, 5, '5', 3),
(67, 6, '4', 3),
(68, 7, '3', 3),
(69, 8, '4', 3),
(70, 9, '3', 3),
(71, 10, '5', 3);

-- --------------------------------------------------------

--
-- Table structure for table `instructors`
--

CREATE TABLE `instructors` (
  `instructor_id` int(11) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `instructors`
--

INSERT INTO `instructors` (`instructor_id`, `first_name`, `last_name`, `email`, `department`) VALUES
(1, 'Noel', 'Garcia', 'example@gmail.com ', 'SCS'),
(2, 'Chistian', 'Anda', 'example@gmail.com ', 'SCS'),
(3, 'Michael', 'Anonuevo', 'example@gmail.com ', 'SCS'),
(4, 'Karen', 'De Villa', 'example@gmail.com ', 'SCS'),
(5, 'Rumer', 'Bayot', 'example@gmail.com ', 'SCS'),
(6, 'Aira', 'Ronquillio', 'example@gmail.com ', 'SCS');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `program` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `first_name`, `last_name`, `email`, `program`) VALUES
(2022010715, 'Emanuel', 'Gonzales', 'eg108151090015@gmail.com ', 'Information Technology '),
(2022010716, 'Ewan', 'Diko Alam', 'example@gmail.com ', 'Computer Science'),
(2022010717, 'Ikaw', 'At Ikaw', 'example@gmail.com ', 'Computer Science'),
(2022010718, 'Jan Andrei', 'Teano', 'example@gmail.com ', 'Information Technology '),
(2022010719, 'Marvin', 'Gonzales', 'example@gmail.com ', 'Information Technology '),
(2022010720, 'Jelo', 'Montegrande', 'example@gmail.com ', 'Information Technology '),
(2022010721, 'Vincent', 'De Asis', 'example@gmail.com', 'Computer Science');

-- --------------------------------------------------------

--
-- Table structure for table `student_courses`
--

CREATE TABLE `student_courses` (
  `student_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_courses`
--

INSERT INTO `student_courses` (`student_id`, `course_id`) VALUES
(2022010715, 1),
(2022010715, 2),
(2022010715, 3),
(2022010715, 4),
(2022010715, 5),
(2022010715, 6),
(2022010715, 7),
(2022010716, 1),
(2022010716, 2),
(2022010716, 3),
(2022010716, 4),
(2022010716, 5),
(2022010716, 6),
(2022010716, 7),
(2022010717, 1),
(2022010717, 2),
(2022010717, 3),
(2022010717, 4),
(2022010717, 5),
(2022010717, 6),
(2022010717, 7),
(2022010718, 1),
(2022010718, 2),
(2022010718, 3),
(2022010718, 4),
(2022010718, 5),
(2022010718, 6),
(2022010718, 7),
(2022010719, 1),
(2022010719, 2),
(2022010719, 3),
(2022010719, 4),
(2022010719, 5),
(2022010719, 6),
(2022010719, 7),
(2022010720, 1),
(2022010720, 2),
(2022010720, 3),
(2022010720, 4),
(2022010720, 5),
(2022010720, 6),
(2022010720, 7),
(2022010721, 1),
(2022010721, 2),
(2022010721, 3),
(2022010721, 4),
(2022010721, 5),
(2022010721, 6),
(2022010721, 7);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_id`),
  ADD KEY `instructor_id` (`instructor_id`);

--
-- Indexes for table `course_feedback`
--
ALTER TABLE `course_feedback`
  ADD PRIMARY KEY (`feedback_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `feedback_questions`
--
ALTER TABLE `feedback_questions`
  ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `feedback_responses`
--
ALTER TABLE `feedback_responses`
  ADD PRIMARY KEY (`feedback_id`),
  ADD KEY `question_id` (`question_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `instructors`
--
ALTER TABLE `instructors`
  ADD PRIMARY KEY (`instructor_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `student_courses`
--
ALTER TABLE `student_courses`
  ADD PRIMARY KEY (`student_id`,`course_id`),
  ADD KEY `course_id` (`course_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `feedback_questions`
--
ALTER TABLE `feedback_questions`
  MODIFY `question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `feedback_responses`
--
ALTER TABLE `feedback_responses`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `instructors`
--
ALTER TABLE `instructors`
  MODIFY `instructor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`instructor_id`) REFERENCES `instructors` (`instructor_id`);

--
-- Constraints for table `course_feedback`
--
ALTER TABLE `course_feedback`
  ADD CONSTRAINT `course_feedback_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  ADD CONSTRAINT `course_feedback_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`),
  ADD CONSTRAINT `course_feedback_ibfk_3` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  ADD CONSTRAINT `course_feedback_ibfk_4` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`),
  ADD CONSTRAINT `course_feedback_ibfk_5` FOREIGN KEY (`feedback_id`) REFERENCES `feedback_responses` (`feedback_id`);

--
-- Constraints for table `feedback_responses`
--
ALTER TABLE `feedback_responses`
  ADD CONSTRAINT `feedback_responses_ibfk_2` FOREIGN KEY (`question_id`) REFERENCES `feedback_questions` (`question_id`),
  ADD CONSTRAINT `feedback_responses_ibfk_3` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`);

--
-- Constraints for table `student_courses`
--
ALTER TABLE `student_courses`
  ADD CONSTRAINT `student_courses_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  ADD CONSTRAINT `student_courses_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
